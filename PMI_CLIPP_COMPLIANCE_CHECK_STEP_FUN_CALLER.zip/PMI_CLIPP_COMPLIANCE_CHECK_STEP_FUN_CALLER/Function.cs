using System.Text.Json;
using Amazon.Lambda.Core;
using Amazon.Lambda.SQSEvents;
using Amazon.StepFunctions;
using Amazon.StepFunctions.Model;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace PMI_CLIPP_COMPLIANCE_CHECK_STEP_FUN_CALLER;


public class Function
{
    private readonly AmazonStepFunctionsClient _stepFunctionsClient;

    public Function()
    {
        _stepFunctionsClient = new AmazonStepFunctionsClient(Amazon.RegionEndpoint.EUWest1);
    }

    /// <summary>
    /// A simple function that takes a string and does a ToUpper
    /// </summary>
    /// <param name="input">The event for the Lambda function handler to process.</param>
    /// <param name="context">The ILambdaContext that provides methods for logging and describing the Lambda environment.</param>
    /// <returns></returns>
    public async Task FunctionHandler(SQSEvent sqsEvent, ILambdaContext context)
    {
        Console.WriteLine("Step 1 : Start of the Execution, Export COMPLIANCE Step Function Caller ");
        //AwsSecretsManager manager = AwsSecretsManager.GetInstance();
        foreach (var message in sqsEvent.Records)
        {
            try
            {
                string arn = string.Empty;

                var sqsMessageBody = JsonSerializer.Deserialize<MessagePayload>(message.Body);
                Console.WriteLine("Step 2 : Get SQS message " + sqsMessageBody);
                if (sqsMessageBody == null)
                {
                    context.Logger.LogLine("Message payload is null.");
                    Console.WriteLine("Step 3 : Message payload is null");
                    continue;
                }
                else
                {
                    string changeId = sqsMessageBody.changeId;
                    string changeType = sqsMessageBody.changeType;
                    string username = sqsMessageBody.username;
                    string activityID = sqsMessageBody.activityID;

                    //Innovator innovator = InnovatorServerConnectionManager.CreateNewInnovatorServerConnection(manager);
                    //Innovator innovator = InnovatorConnectionManager.GetNewInnovatorConnection();
                    string startTime = DateTime.UtcNow.ToString("yyyy-MM-dd hh:mm:ss tt");

                    arn = Environment.GetEnvironmentVariable("AWS_COMPLIANCE_STEPFUNCTION_ARN");
                    var stepFunctionInput = JsonSerializer.Serialize(new
                    {
                        changeId = sqsMessageBody.changeId,
                        changeType = sqsMessageBody.changeType,
                        username = sqsMessageBody.username,
                        activityID = sqsMessageBody.activityID,
                        Error = new
                        {
                            IsError = false,
                            ErrorMessage = "",
                            ExceptionStackTrace = ""
                        }
                    });
                    Console.WriteLine("Step 4 : Send request to Step Function " + arn);
                    string modified_pbc_number = sqsMessageBody.changeId.Replace(" ", "-");
                    var executionName = $"Execution-{modified_pbc_number}-{DateTime.UtcNow:yyyyMMddHmmss}";
                    var request = new StartExecutionRequest
                    {
                        StateMachineArn = arn,
                        Input = stepFunctionInput,
                        Name = executionName
                    };

                    var response = await _stepFunctionsClient.StartExecutionAsync(request);
                    Console.WriteLine("Step 5 : Response from Step Function " + response);
                    if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                    {
                        startTime = DateTime.UtcNow.ToString("yyyy-MM-dd hh:mm:ss tt");
                        Console.WriteLine($"Step 6 : Step Function started successfully with Execution ARN: {response.ExecutionArn}");
                        context.Logger.LogLine($"Step Function started successfully with Execution ARN: {response.ExecutionArn}");
                    }
                    else
                    {
                        startTime = DateTime.UtcNow.ToString("yyyy-MM-dd hh:mm:ss tt");
                        Console.WriteLine("Step 7 : Failed to start Step Function.");
                        context.Logger.LogLine("Failed to start Step Function.");
                    }
                }


            }
            catch (Exception ex)
            {
                string startTime = DateTime.UtcNow.ToString("yyyy-MM-dd hh:mm:ss tt");
                Console.WriteLine($"Error processing message: {ex.Message}");
                context.Logger.LogLine($"Error processing message: {ex.Message}");
            }
        }
    }

    public class MessagePayload
    {
        public string changeId { get; set; }
        public string changeType { get; set; }
        public string username { get; set; }
        public string activityID { get; set; }
    }
}
