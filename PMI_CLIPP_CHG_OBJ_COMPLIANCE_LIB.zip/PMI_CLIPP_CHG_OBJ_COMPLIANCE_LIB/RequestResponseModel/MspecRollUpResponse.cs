﻿using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CommonDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.RequestResponseModel
{
    public class MspecRollUpResponse
    {
        public string ChangeObjectId { get; set; }
        public string ChangeObjectNumber { get; set; }
        public string complianceResult { get; set; }
        public List<ChangeObjectRollUpResponse> mSpecComplainceCheckCollection { get; set; }

        public string mSpecNumber { get; set; }
        public ErrorInformation Error { get; set; }
        public string statusMessage { get; set; }

        public string mSpecAltNumber { get; set; }

        public string mSpecPVNumber { get; set; }

        public string mSpecId { get; set; }

        public string mSpecPVId { get; set; }

        public string mSpecAltId { get; set; }

        public string changeNumber { get; set; }

        public string changeId { get; set; }
        public string username { get; set; }
        public string CheckType { get; set; }

        public List<ComplianceCheckRequestResponse> ChgAffItemsDetail { get; set; }
        public string activityID { get; set; }

    }
}