﻿using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CommonDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.RequestResponseModel
{
    public class ConsolidatedErrorAndResultResponse
    {

        public string complianceResult { get; set; }
        public ErrorInformation Error { get; set; }
        public List<ChangeObjectRollUpResponse> ChgAffItemsDetail { get; set; }
        public string activityID { get; set; }
        public string changeId { get; set; }

        public string changeType { get; set; }

        public List<ComplianceCheckRequestResponse> EcoChgAffItemsDetail { get; set; }

    }
}
