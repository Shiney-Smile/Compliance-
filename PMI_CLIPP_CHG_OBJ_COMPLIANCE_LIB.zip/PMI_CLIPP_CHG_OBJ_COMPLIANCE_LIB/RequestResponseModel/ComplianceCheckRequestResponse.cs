﻿using Aras.IOM;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CommonDataModel;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.RequestResponseModel
{
    public class ComplianceCheckRequestResponse
    {
        public string changeNumber { get; set; }
        public string changeType { get; set; }
        public string username { get; set; }
        public string partNumber { get; set; }
        public string subFamilyPart { get; set; }
        public bool isMultiLevel { get; set; }
        public string partId { get; set; }
        public string partItemType { get; set; }
        public string changeId { get; set; }
        public string pvId { get; set; }
        public string pvNumber { get; set; }
        public string pvProductCategoryLabel { get; set; }
        public string pvProductTypeLabel { get; set; }
        public string mSpecId { get; set; }

        public string mSpecAltId { get; set; }
        
        public string mSpecPVId { get; set; }
        public string mSpecNumber { get; set; }

        public string mSpecAltNumber { get; set; }
        public List<MspecDataModel> mSpecDataModel { get; set; }

        public string mSpecType { get; set; }
        //public List<AffectedItemParts> partsMultiLevel { get; set; }
        public List<ChangeObjectAffectedItem> affectedItems { get; set; }
        public List<AffectedItemParts> singleLevelParts { get; set; }

        public string complianceResult { get; set; }
        public ErrorInformation Error { get; set; }

        public int affectedItemCount { get; set; }

        public string statusMessage { get; set; }

        public List<string> mcoStatusMessage { get; set; }
        public string context_item_type { get; set; }
        public string context_item_id { get; set; }
        public string context_item_keyed_name { get; set; }
        public string plant_name { get; set; }
        public string plant_id { get; set; }
        public string ebom_item_id { get; set; }
        public string ebom_item_type { get; set; }
        public List<LOCCompliance> match_result_collection { get; set; }
        public string production_center { get; set; }
        public string item_id { get; set; }
        public string item_type { get; set; }
        public string pmi_item_code { get; set; }
        public string pmi_compliance_status { get; set; }
        public string pmi_child_compliance_status { get; set; }
        public string pmi_business_compliance { get; set; }
        public string pmi_container { get; set; }
        public string pmi_status_message { get; set; }

        public bool businessLimitationflag { get; set; }
        public bool complianceInputflag { get; set; }
        public bool LocalizationScreen { get; set; }
        public List<ChangeObjectAffectedItem> partComplainceCheckCollection { get; set; }

        public bool isPVApplicable { get; set; }
        public bool isPartApplicable { get; set; }

        public string activityID { get; set; }
        
    }
}