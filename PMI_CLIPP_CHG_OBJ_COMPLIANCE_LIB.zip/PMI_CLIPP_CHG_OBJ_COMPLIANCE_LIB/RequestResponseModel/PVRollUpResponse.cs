﻿using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CommonDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.RequestResponseModel
{
    public class PVRollUpResponse
    {
        public string ChangeObjectId { get; set; }
        public string pvId { get; set; }
        public string pvNumber { get; set; }
        public string ChangeObjectNumber { get; set; }
        public string partId { get; set; }
        public string partNumber { get; set; }
        public string complianceResult { get; set; }
        public bool businessLimitationflag { get; set; }
        public bool complianceInputflag { get; set; }
        public List<ChangeObjectRollUpResponse> pvComplainceCheckCollection { get; set; }
        public ErrorInformation Error { get; set; }
        public string statusMessage { get; set; }
        public string username { get; set; }

        public string checkType { get; set; }

        public bool isPVApplicable { get; set; }
        public List<ChangeObjectRollUpResponse> ChgAffItemsDetail { get; set; }

        public string activityID { get; set; }
        public string changeType { get; set; }
        public string changeId { get; set; }
    }
}