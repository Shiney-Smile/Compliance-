﻿namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util
{
    public class ComplianceResult
    {

        public const string Compliant = "compliant";

        public const string NonCompliant = "non-compliant";

        public const string OtherLimitaton = "other-limitation";

    }
}
