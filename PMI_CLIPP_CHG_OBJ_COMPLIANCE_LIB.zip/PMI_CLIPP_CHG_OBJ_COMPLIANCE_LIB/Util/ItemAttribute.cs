﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util
{
    public class ItemAttribute
    {
        public static string SELECT = "select";
    }
}
