﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util
{
    public class ItemTypeName
    {
        public static string ExpressECO = "Express ECO";

        public static string ExpressECOAffectedItem = "Express ECO Affected Item";

        public static string ExpressECOChangeControlItem = "Change Controlled Item";

        public static string ProductECO = "pmi_ProductECO";

        public static string ProductECOAffectedItem = "pmi_ProductECO_AffectedItem";

        public static string ProductECOPolyItem = "pmi_ProductECO_PolyItem";

        public static string MCO = "pmi_mSpecMCO";

        public static string MCOAffectedItem = "pmi_mSpecMCO_AffectedItem";

        public static string Part = "Part";

        public const string ProductVariantMarket = "pmi_ProductVariant_Market";

        public const string Market = "pmi_Market";

        public const string ChangeObjectProdCatMapping = "pmi_Chg_Obj_Prod_Categ_Mapping";

        public const string BusinessLmtMapping = "pmi_BusinessLmtApplicability";

        public const string Parameters = "pmi_Parameters";

        public const string GHP = "pmi_GlobalHarmonizedParameters";

        public const string PVPartSelection = "pmi_PVPartSelection";

        public const string StructureGHPContainers = "pmi_StructureGHPContainers";

        public const string ParameterStructure = "pmi_ParameterStructure";

        public const string ProductVariant = "pmi_ProductVariant";

        public const string GlobalProduct = "pmi_GlobalProduct";

        public const string SellableProduct = "pmi_SellableProduct";

        public const string mSpecAlternative = "mSpec Alternative";

        public const string ComplianceObjectDataModel = "pmi_CompObjPartBoMDataModel";

        public const string ComplianceBOMHideRules = "pmi_ComplianceBOMHideRulesNew";

        public const string ListofItemTypesToHide = "pmi_ListOfItemTypesToHideNew";

        public const string mSpec = "pmi_LocalPart";

        public const string mSpecBOM = "pmi_LocalPartBOM";


        public static string Plant = "pmi_Plant";

        public const string stateName = "Suppressed";
        public const string preliminaryState = "Preliminary";
        public const string cancelledState = "Cancelled";

        public const string combustibleMspec = "Combustible mSpec";
        public const string consumableMspec = "Consumable mSpec";
        public const string productVariantMspec = "Product Variant mSpec";
        public const string filtermspec = "Filter mSpec";
        public const string filtersemimspec = "Filter Semi mSpec";

        public const string compInputParatmeters = "pmi_CompRptInputParameters";
        public const string checkTypeCompliance = "Compliance";
        public const string checkTypeBusinessLmt = "Business Limitation";

        public const string method = "Method";

        public const string pathNameMCO = "Sent Back to Define Change";
        public const string Activity = "Activity";
        public const string notApplicable = "Not Applicable";
        public const string approval = "Approval";
    }
}
