﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util
{
    public class ItemTypeProperty
    {
        public static string ID = "id";

        public static string KeyedName = "keyed_name";

        public static string STATE = "state";


    }
}
