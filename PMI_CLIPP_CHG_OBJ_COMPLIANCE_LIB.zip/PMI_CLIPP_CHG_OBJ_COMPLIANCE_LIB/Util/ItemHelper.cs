﻿using Aras.IOM;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CustomException;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType.ChangeObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util
{
    public class ItemHelper
    {
        public static string GetKeyedNameById(Innovator innovator, string itemType, string id)
        {
            if(string.IsNullOrEmpty(itemType)) throw new InvalidItemTypeException();
            if (string.IsNullOrEmpty(id)) throw new InvalidIDException();

            string sql = string.Format(@"select keyed_name from innovator.[{0}] where id='{1}'", itemType, id);
            Item resultItem = innovator.applySQL(sql);
            if (resultItem.isError())
                throw new InvalidOperationException("GetKeyedNameById() : Error String From Innovator Server " + resultItem.getErrorString());

            return resultItem.getProperty(ItemTypeProperty.KeyedName);
        }

        public static string GetIdByKeyedName(Innovator innovator, string itemType, string keyed_name)
        {
            if (string.IsNullOrEmpty(itemType)) throw new InvalidItemTypeException();
            if (string.IsNullOrEmpty(keyed_name)) throw new InvalidKeyedNameException();

            string sql = string.Format(@"select id from innovator.[{0}] where keyed_name='{1}' and is_current='1'", itemType, keyed_name);
            Item resultItem = innovator.applySQL(sql);
            if (resultItem.isError())
                throw new InvalidOperationException("GetIdByKeyedName() : Error String From Innovator Server " + resultItem.getErrorString());

            return resultItem.getProperty(ItemTypeProperty.ID);
        }

        public static Item GetItemByKeyedName(Innovator innovator, string itemType, string keyed_name)
        {
            if (string.IsNullOrEmpty(itemType)) throw new InvalidItemTypeException();
            if (string.IsNullOrEmpty(keyed_name)) throw new InvalidKeyedNameException();

            string sql = string.Format(@"select id,keyed_name from innovator.[{0}] with (nolock) where keyed_name='{1}' and is_current='1'", itemType, keyed_name);
            Item resultItem = innovator.applySQL(sql);
            if (resultItem.isError())
                throw new InvalidOperationException("GetIdByKeyedName() : Error String From Innovator Server " + resultItem.getErrorString());

            return resultItem;
        }

        public static string GetListLableFromValue(Innovator innovator, string listId, string listRelationshipName , string value )
        {
            Item getListValue = innovator.newItem(listRelationshipName, "get");
            getListValue.setProperty("source_id", listId);
            getListValue.setProperty("value", value);
            getListValue.setAttribute("select", "label");
            Item resultItem  = getListValue.apply();
            if (resultItem.isError())
                throw new Exception("ItemHelper: GetListLableFormaValue(): Product Category or Product Type list not found" + resultItem);

            return resultItem.getProperty("label");
            
        }
        public static string GetKeyedNameById_Aml(Innovator innovator, string itemType, string id)
        {
            if (string.IsNullOrEmpty(itemType) || string.IsNullOrEmpty(id))
            {
                throw new InvalidOperationException("GetKeyedNameById_Aml() :itemType or ID is empty");
            }

            Item qItem = innovator.newItem(itemType, ItemAction.GET);
            qItem.setProperty(ItemTypeProperty.ID, id);
            qItem.setAttribute("select", ItemTypeProperty.KeyedName);
            Item resultItem = qItem.apply();

            if (resultItem.isError())
                throw new InvalidOperationException("GetKeyedNameById_Aml() : Error String From Innovator Server " + resultItem.getErrorString() + " qITem= " + qItem);

            return resultItem.getProperty(ItemTypeProperty.KeyedName);
        }
    }
}