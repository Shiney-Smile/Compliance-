﻿using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.RequestResponseModel;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CustomException
{
    public class InvalidChangeObjectIdException : Exception
    {
        public InvalidChangeObjectIdException() : base("Input request does not contain change object id")
        { }
    }

    public class ECORelationshipException : Exception
    {
        public ECORelationshipException() : base("Express ECO :: GetAffectedItems Method :: Not able to retrive Express ECO Rel")
        { }
    }
    public class PECORelationshipException : Exception
    {
        public PECORelationshipException() : base("Product ECO :: GetAffectedItems Method :: Not able to retrive Product ECO Rel")
        { }
    }
    public class InvalidPartNumberException : Exception
    {
        public InvalidPartNumberException() : base("Input request does not contain part number")
        { }
    }
    public class InvalidPartIDException : Exception
    {
        public InvalidPartIDException() : base("Input request does not contain part ID")
        { }
    }

    public class InvalidMSpecIDException : Exception
    {
        public InvalidMSpecIDException() : base("Input request does not contain mspec ID")
        { }
    }
    public class InvalidPVIDException : Exception
    {
        public InvalidPVIDException() : base("Input request does not contain PV ID")
        { }
    }

    public class InvalidProductVariantNumber : Exception
    {
        public InvalidProductVariantNumber(ComplianceCheckRequestResponse request) : base(string.Format("Change Object Request For PECO {0} does not contain information about the product variant key", request.changeNumber))
        { }
    }

    public class InvalidProductCategory : Exception
    {
        public InvalidProductCategory(ComplianceCheckRequestResponse request) : base(string.Format("Get product variant parts request for PV {0} does not contain information about the product category", request.pvNumber))
        { }
    }

    public class InvalidProductType : Exception
    {
        public InvalidProductType(ComplianceCheckRequestResponse request) : base(string.Format("Get product variant parts request for PV {0} does not contain information about the product type", request.pvNumber))
        { }
    }


    public class InvalidChangeTypeException : Exception
    {
        public InvalidChangeTypeException() : base("Input request does not contain change type")
        { }
    }

    public class InvalidItemTypeException : Exception
    {
        public InvalidItemTypeException() : base("Input request does not contain itemtype")
        { }
    }

    public class InvalidIDException : Exception
    {
        public InvalidIDException() : base("Input request does not contain itemtype")
        { }
    }

    public class InvalidKeyedNameException : Exception
    {
        public InvalidKeyedNameException() : base("Input request does not contain itemtype")
        { }
    }

    public class InvalidMSPECIDException : Exception
    {
        public InvalidMSPECIDException() : base("Input request does not contain mSpec ID")
        { }
    }

    public class InvalidMSPECNumberException : Exception
    {
        public InvalidMSPECNumberException() : base("Input request does not contain mSpec Number")
        { }
    }
    public class InvalidContextItemTypeException : Exception
    {
        public InvalidContextItemTypeException() : base("Input request does not contain Context Item type")
        { }
    }
    public class InvalidContextItemIdException : Exception
    {
        public InvalidContextItemIdException() : base("Input request does not contain Context Item Id")
        { }
    }
    public class InvalidContextItemKeyedName : Exception
    {
        public InvalidContextItemKeyedName() : base("Input request does not contain Context Item Keyed Name")
        { }
    }
    public class InvalidPlantName : Exception
    {
        public InvalidPlantName() : base("Input request does not contain Plant Name")
        { }
    }
    public class InvalidPlantIdException : Exception
    {
        public InvalidPlantIdException() : base("Input request does not contain Plant Id")
        { }
    }
    public class InvalidEbomItemIdException : Exception
    {
        public InvalidEbomItemIdException() : base("Input request does not contain Ebom Item Id")
        { }
    }
    public class InvalidEbomItemType : Exception
    {
        public InvalidEbomItemType() : base("Input request does not contain Ebom Item type")
        { }
    }
    public class InvalidProductionCenterIdException : Exception
    {
        public InvalidProductionCenterIdException() : base("Input request does not contain Production Center ID")
        { }
    }
    public class InvalidItemIdException : Exception
    {
        public InvalidItemIdException() : base("Input request does not contain Item ID")
        { }
    }
    public class InvalidUsernameException : Exception
    {
        public InvalidUsernameException() : base("Input request does not contain Username")
        { }
    }
    public class InvalidActivityIdException : Exception
    {
        public InvalidActivityIdException() : base("Input request does not contain activity id")
        { }
    }
}