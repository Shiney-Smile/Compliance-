﻿using Aras.IOM;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ConnectionManager
{
    public class InnovatorConnectionManager
    {
        public static Innovator GetNewInnovatorConnection()
        {
            AwsKeyManager.RetriveSecrtesFromVault();

            string HostName = AwsKeyManager.HostName;
            string Database = AwsKeyManager.Database;
            string UserName = AwsKeyManager.UserName;
            string Password = AwsKeyManager.Password;

            if (string.IsNullOrEmpty(HostName))
                throw new ArgumentNullException("InnovatorConnectionManager:GetNewInnovatorConnection(): Innovator Server Host Name is Null/Empty");

            if (string.IsNullOrEmpty(Database))
                throw new ArgumentNullException("InnovatorConnectionManager:GetNewInnovatorConnection(): Innovator Server Database is Null/Empty");

            if (string.IsNullOrEmpty(UserName))
                throw new ArgumentNullException("InnovatorConnectionManager:GetNewInnovatorConnection(): Innovator Server User Name is Null/Empty");

            if (string.IsNullOrEmpty(Password))
                throw new ArgumentNullException("InnovatorConnectionManager:GetNewInnovatorConnection(): Innovator Server Password is Null/Empty");
            Item loginItem = null;
            for (int index = 0; index < 3; index++)
            {
                Console.WriteLine($"GetNewInnovatorConnection():Attempt {index}: Connecting to Innovator at {HostName}...");
                HttpServerConnection connection = (HttpServerConnection)IomFactory.CreateHttpServerConnection(HostName, Database, UserName, Password);
                loginItem = connection.Login();

                if (loginItem.isError())
                {
                    if (index < 3)
                    {
                        Console.WriteLine($"GetNewInnovatorConnection():Login attempt {index} failed: {loginItem.getErrorDetail()}");
                        continue;
                    }
                    else
                    {
                        throw new Exception(string.Format(@"InnovatorConnectionManager:GetNewInnovatorConnection(): Program is unable to login to Aras Server {0}, Error Details"
                                                        , HostName, loginItem.getErrorDetail()));
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("GetNewInnovatorConnection():1. Login successful." + loginItem.ToString());
                    return loginItem.getInnovator();
                }
            }
            if (loginItem != null)
            {
                Console.WriteLine("GetNewInnovatorConnection():2. Login successful." + loginItem.ToString());
                return loginItem.getInnovator();
            }
            else
            {
                throw new Exception("Login Item object is null");
            }
        }
        public static Item GetNewInnovatorConnection(string HostName,string Database , string UserName , string Passowrd = "innovator")
        {
            if (string.IsNullOrEmpty(HostName))
                throw new ArgumentNullException("InnovatorConnectionManager:GetNewInnovatorConnection(): Innovator Server Host Name is Null/Empty");

            if (string.IsNullOrEmpty(Database))
                throw new ArgumentNullException("InnovatorConnectionManager:GetNewInnovatorConnection(): Innovator Server Database is Null/Empty");

            if (string.IsNullOrEmpty(UserName))
                throw new ArgumentNullException("InnovatorConnectionManager:GetNewInnovatorConnection(): Innovator Server User Name is Null/Empty");

            HttpServerConnection connection = (HttpServerConnection)IomFactory.CreateHttpServerConnection(HostName,Database,UserName,Passowrd);
            Item loginItem = connection.Login();

            if(loginItem.isError())
                throw new Exception(string.Format(@"InnovatorConnectionManager:GetNewInnovatorConnection(): Program is unable to login to Aras Server {0}, Error Details"
                                                        ,HostName, loginItem.getErrorDetail()));
            return loginItem;
        }
        public static void Logout(Innovator innovator)
        {
            if (innovator != null)
                ((HttpServerConnection)innovator.getConnection()).Logout();
            else
                throw new ArgumentNullException("InnovatorConnectionManager:Logout(): Inovator object is null, please check Aras Connection");
        }
    }
}