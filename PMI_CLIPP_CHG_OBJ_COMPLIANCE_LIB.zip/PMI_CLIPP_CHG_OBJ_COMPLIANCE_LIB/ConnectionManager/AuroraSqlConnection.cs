﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySqlConnector;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ConnectionManager
{
    public class AuroraSqlConnection
    {
        string current_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);

        public static MySqlConnection createConnection(string auroraServer, string auroraUser, string auroraDb, string auroraDbPwd)
        {
            try
            {
                string connString = String.Format("server={0};user={1};database={2};password={3}", auroraServer, auroraUser, auroraDb, auroraDbPwd);
                Console.WriteLine("createConnection():Attempting to create MySQL connection...");

                MySqlConnection connection = new MySqlConnection(connString);
                connection.Open();

                Console.WriteLine("createConnection():Connection established successfully." + "Server:"+ auroraServer +", User:"+ auroraUser+ ", Database:" + auroraDb+ ", Db Password:" + auroraDbPwd);
                return connection;
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("createConnection():MySQL error occurred: " + ex.Message + "Server:" + auroraServer + ", User:" + auroraUser + ", Database:" + auroraDb + ", Db Password:" + auroraDbPwd);
            }
            catch (Exception ex)
            {
                Console.WriteLine("createConnection():An error occurred: " + ex.Message + "Server:" + auroraServer + ", User:" + auroraUser + ", Database:" + auroraDb + ", Db Password:" + auroraDbPwd);
            }

            return null;
        }


        public static void InsertComplianceResultRow(MySqlConnection conn, string ChangeId, string ItemCode, string ComplianceResult, string Message, string current_date, string ChangeType)
        {
            string fullQuery = "";
            try
            {
                string sql = @"INSERT INTO PMI_MonitoringDatabase.PMI_COMPLIANCE_RESULT
                       (ChangeId, ItemCode, ComplianceResult, Message, DateTime, CheckType)
                       VALUES (@ChangeId, @ItemCode, @ComplianceResult, @Message, @DateTime, @CheckType)";

                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@ChangeId", ChangeId);
                    cmd.Parameters.AddWithValue("@ItemCode", ItemCode);
                    cmd.Parameters.AddWithValue("@ComplianceResult", ComplianceResult);
                    cmd.Parameters.AddWithValue("@Message", Message);
                    cmd.Parameters.AddWithValue("@DateTime", current_date);
                    cmd.Parameters.AddWithValue("@CheckType", ChangeType);

                    fullQuery = $"INSERT INTO PMI_MonitoringDatabase.PMI_COMPLIANCE_RESULT " +
                                       $"(ChangeId, ItemCode, ComplianceResult, Message, DateTime, CheckType) VALUES " +
                                       $"('{ChangeId}', '{ItemCode}', '{ComplianceResult}', '{Message}', '{current_date}', '{ChangeType}')";
                    Console.WriteLine("InsertComplianceResultRow():Executing SQL Query: " + fullQuery);

                    cmd.ExecuteNonQuery();
                    Console.WriteLine("InsertComplianceResultRow():Insert successful.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("InsertComplianceResultRow():Error inserting compliance result row: " + ex.Message+ "Executing SQL Query: " + fullQuery);
                throw;
            }
        }

        public static void UpdateComplianceResult(string ChangeId, string ItemCode, string ComplianceResult, string Message, string current_date, string ChangeType)
        {
            AwsKeyManager.RetriveSecrtesFromVault();
            MySqlConnection conn = null;

            string AuroraDBendpoint = AwsKeyManager.AuroraDBendpoint;
            string AuroraDBuserName = AwsKeyManager.AuroraDBuserName;
            string AuroraDatabase = AwsKeyManager.AuroraDatabase;
            string AuroraDBpassword = AwsKeyManager.AuroraDBpassword;

            if (string.IsNullOrEmpty(AuroraDBendpoint))
                throw new ArgumentNullException(nameof(AuroraDBendpoint), "Aurora DB endpoint is null or empty.");

            if (string.IsNullOrEmpty(AuroraDBuserName))
                throw new ArgumentNullException(nameof(AuroraDBuserName), "Aurora DB username is null or empty.");

            if (string.IsNullOrEmpty(AuroraDatabase))
                throw new ArgumentNullException(nameof(AuroraDatabase), "Aurora DB database name is null or empty.");

            if (string.IsNullOrEmpty(AuroraDBpassword))
                throw new ArgumentNullException(nameof(AuroraDBpassword), "Aurora DB password is null or empty.");

            try
            {
                Console.WriteLine("UpdateComplianceResult():Creating Aurora SQL connection...");
                conn = AuroraSqlConnection.createConnection(AuroraDBendpoint, AuroraDBuserName, AuroraDatabase, AuroraDBpassword);
                Console.WriteLine("UpdateComplianceResult():Connection established. Inserting compliance result...");

                InsertComplianceResultRow(conn, ChangeId, ItemCode, ComplianceResult, Message, current_date, ChangeType);

                Console.WriteLine("UpdateComplianceResult():Compliance result inserted successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("UpdateComplianceResult():Error in UpdateComplianceResult: " + ex.Message);
                throw;
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                    Console.WriteLine("UpdateComplianceResult():Connection closed.");
                }
            }
        }


    }
}