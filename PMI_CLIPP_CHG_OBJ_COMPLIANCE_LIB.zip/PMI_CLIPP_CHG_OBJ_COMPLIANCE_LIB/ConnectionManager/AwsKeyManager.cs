﻿using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using Newtonsoft.Json.Linq;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ConnectionManager
{
    public class AwsKeyManager
    {
        private const string InnovatorHostNameKey = "compliance/check/automation/innovator/hostname";
        private const string InnovatorDatabaseKey = "compliance/check/automation/innovator/database";
        private const string InnovatorUserNameKey = "compliance/check/automation/innovator/username";
        private const string InnovatorPasswordKey = "compliance/check/automation/innovator/password";
        private const string AuroraDBendpointKey = "compliance/check/automation/aurora/endpoint";
        private const string AuroraDatabaseKey = "compliance/check/automation/aurora/database";
        private const string AuroraDBuserNameKey = "compliance/check/automation/aurora/username";
        private const string AuroraDBpasswordKey = "compliance/check/automation/aurora/password";
        public static string HostName { get; set; }
        public static string Database { get; set; }
        public static string UserName { get; set; }
        public static string Password { get; set; }
        public static string AuroraDBendpoint { get; set; }
        public static string AuroraDBuserName { get; set; }
        public static string AuroraDatabase { get; set; }
        public static string AuroraDBpassword { get; set; }


        public static void RetriveSecrtesFromVault()
        {
            IAmazonSecretsManager client = new AmazonSecretsManagerClient(Amazon.RegionEndpoint.EUWest1);

            GetSecretValueRequest request = new GetSecretValueRequest
            {
                SecretId = "compliance/check/automation",
                VersionStage = "AWSCURRENT"
            };

            try
            {
                Console.WriteLine("RetriveSecrtesFromVault(): Retrieving secrets from AWS Secrets Manager...");
                var response = client.GetSecretValueAsync(request).GetAwaiter().GetResult();

                if (string.IsNullOrEmpty(response.SecretString))
                {
                    throw new Exception("RetriveSecrtesFromVault(): Secret string is empty.");
                }

                JObject jObject = JObject.Parse(response.SecretString);

                HostName = jObject[InnovatorHostNameKey].ToString();
                Database = jObject[InnovatorDatabaseKey].ToString();
                UserName = jObject[InnovatorUserNameKey].ToString();
                Password = jObject[InnovatorPasswordKey].ToString();
                AuroraDBendpoint = jObject[AuroraDBendpointKey].ToString();
                AuroraDBuserName = jObject[AuroraDBuserNameKey].ToString();
                AuroraDatabase = jObject[AuroraDatabaseKey].ToString();
                AuroraDBpassword = jObject[AuroraDBpasswordKey].ToString();

                Console.WriteLine("RetriveSecrtesFromVault(): Secrets retrieved and parsed successfully.");
            }
            catch (Exception e)
            {

                Console.WriteLine("RetriveSecrtesFromVault(): Error retrieving secrets: " + e.Message);
                throw;

            }
        }
    }
}