﻿using Aras.IOM;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType
{
    public class ProductVariant
    {
        private Innovator innovator = null;
        public string id = string.Empty;
        public string keyedName = string.Empty;
        public string changeType = string.Empty;
        public ProductVariant(Innovator innovator)
        {
            this.innovator = innovator;
        }
        public ProductVariant(Innovator innovator, string itemId, string keyedName)
        {
            this.innovator = innovator;
            this.id = itemId;
            this.keyedName = keyedName;
        }
        public List<ProductVariant> FetchPV(string partName)
        {
            if (partName == null)
            {
                throw new ArgumentNullException("ProductVariant::FetchPV() : part number is null.");
            }
            bool checkType = CheckApplicabilityOfPart(partName, changeType);
            if (checkType == true)
            {
                Item partData = GetPartByKeyedName(partName);
                if (partData == null)
                {
                    throw new ArgumentNullException("ProductVariant::FetchPV() : part data is null.");
                }
                List<string> collectionPC = GetProductionCenter(partData.getID());
                foreach (var item in collectionPC)
                {
                    Console.WriteLine(partName + "->" + "Production Centers-> " + item);
                }

                Item result = innovator.applySQL(string.Format(@"
                      SELECT pv.id, pv.KEYED_NAME
                        FROM innovator.PMI_PRODUCTVARIANT pv with(nolock)
                        JOIN innovator.PMI_PVITEMSELECTION pvs ON pv.id = pvs.SOURCE_ID
                        JOIN innovator.PMI_STRUCTUREGHPCONTAINERS sgc ON pvs.id = sgc.SOURCE_ID
                        JOIN innovator.PMI_PVGHPCONTAINERS pc ON sgc.RELATED_ID = pc.id
                        WHERE pc.PMI_PARAMETER_VALUE = '{0}' AND pv.is_current = '1'", partName));
                if (result.isError() || result.getItemCount() <= 0)
                {
                    throw new Exception("ProductVariant::FetchPV() : No Product Variants found for the part " + partName);
                }
                List<ProductVariant> variants = new List<ProductVariant>();

                if (!result.isError() && !result.isEmpty() && result.getItemCount() > 0)
                {
                    int count = result.getItemCount();
                    for (int i = 0; i < count; i++)
                    {
                        variants.Add(new ProductVariant(innovator, result.getItemByIndex(i).getProperty("id", ""), result.getItemByIndex(i).getProperty("keyed_name", "")));
                    }
                }

                List<ProductVariant> marketCollection = new List<ProductVariant>();
                foreach (var item in variants)
                {
                    Item market = item.GetMarketRelByPV(item.id);

                    if (market.isError() || market.getItemCount() <= 0)
                    {
                        continue;
                    }
                    int count = market.getItemCount();
                    for (int i = 0; i < count; i++)
                    {
                        Item marketName = item.GetMarketByRel(market.getItemByIndex(i).getProperty("related_id"));
                        if (marketName == null)
                        {
                            throw new ArgumentNullException("ProductVariant::FetchPV() : market data is null.");
                        }
                        marketCollection.Add(new ProductVariant(innovator, item.keyedName, marketName.getProperty("keyed_name")));
                    }
                }
                return marketCollection;
            }
            else
            {
                Console.WriteLine("Part is not applicable! ");
                return null;
            }
        }

        public Item GetMarketRelByPV(string pvId)
        {
            Item market = innovator.newItem(ItemTypeName.ProductVariantMarket, "get");
            market.setProperty("source_id", pvId);
            market = market.apply();
            return market;
        }
        public Item GetMarketByRel(string marketRelId)
        {
            Item marketName = innovator.newItem(ItemTypeName.Market, "get");
            marketName.setProperty("id", marketRelId);
            marketName = marketName.apply();
            if (marketName.isError() || marketName.getItemCount() <= 0)
            {
                throw new Exception("ProductVariant::FetchPV() : no data ");
            }
            return marketName;
        }
        public Boolean CheckApplicabilityOfPart(Item partItem, string changeType)
        {
            //Item Part1 = GetPartByKeyedName(partName);
            string type = partItem.getProperty("classification", "");
            string subFamilyPart = partItem.getProperty("pmi_sub_families", "");

            Item part = innovator.newItem(ItemTypeName.ChangeObjectProdCatMapping, "get");
            part.setProperty("pmi_part_item_type", type);
            part.setProperty("pmi_part_sub_family", subFamilyPart);
            if (changeType == ItemTypeName.ExpressECO)
            {
                part.setPropertyCondition("pmi_change_type", "like");
                part.setProperty("pmi_change_type", "%,ECO,%");
            }
            else if (changeType == ItemTypeName.ProductECO)
            {
                part.setPropertyCondition("pmi_change_type", "like");
                part.setProperty("pmi_change_type", "%,PECO,%");
            }
            part = part.apply();
            if (part.getItemCount() > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public Boolean CheckApplicabilityOfPart(string partName, string changeType)
        {
            Item Part1 = GetPartByKeyedName(partName);
            string type = Part1.getProperty("classification", "");
            string subFamilyPart = Part1.getProperty("pmi_sub_families", "");

            Item part = innovator.newItem(ItemTypeName.ChangeObjectProdCatMapping, "get");
            part.setProperty("pmi_part_item_type", type);
            part.setProperty("pmi_part_sub_family", subFamilyPart);
            if (changeType == ItemTypeName.ExpressECO)
            {
                part.setPropertyCondition("pmi_change_type", "like");
                part.setProperty("pmi_change_type", "%,ECO,%");
            }
            else if (changeType == ItemTypeName.ProductECO)
            {
                part.setPropertyCondition("pmi_change_type", "like");
                part.setProperty("pmi_change_type", "%,PECO,%");
            }
            part = part.apply();
            if (part.getItemCount() > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public Boolean CheckBusinessLmtApplicabilityOfPart(Item partItem, string changeType)
        {
            //Item Part1 = GetPartByKeyedName(partName);
            string type = partItem.getProperty("classification", "");
            string subFamilyPart = partItem.getProperty("pmi_sub_families", "");

            Item part = innovator.newItem(ItemTypeName.BusinessLmtMapping, "get");
            part.setProperty("pmi_part_item_type", type);
            part.setProperty("pmi_part_sub_family", subFamilyPart);
            if (changeType == ItemTypeName.ExpressECO)
            {
                part.setPropertyCondition("pmi_business_lmt_chg_type", "like");
                part.setProperty("pmi_business_lmt_chg_type", "%,ECO,%");
            }
            else if (changeType == ItemTypeName.ProductECO)
            {
                part.setPropertyCondition("pmi_business_lmt_chg_type", "like");
                part.setProperty("pmi_business_lmt_chg_type", "%,PECO,%");
            }
            part = part.apply();
            if (part.getItemCount() > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public Item GetPartByKeyedName(string partName)
        {
            Item part = innovator.newItem(ItemTypeName.Part, "get");
            part.setPropertyCondition("keyed_name", "like");
            part.setProperty("keyed_name", partName);
            part.setAttribute("serverEvents", "0");
            part = part.apply();
            return part;
        }
        public List<string> GetProductionCenter(string partId)
        {
            Item part = innovator.newItem(ItemTypeName.Parameters, "get");
            part.setProperty("source_id", partId);
            part.setAttribute("select", "related_id,pmi_text_value");
            part = part.apply();

            List<string> productionCenter = new List<string>();
            int count = part.getItemCount();
            for (int i = 0; i < count; i++)
            {
                string text = part.getItemByIndex(i).getProperty("pmi_text_value");

                Item partParameter = innovator.newItem(ItemTypeName.GHP, "get");
                partParameter.setProperty("id", part.getItemByIndex(i).getProperty("related_id"));
                partParameter.setProperty("pmi_description", "Production Center");
                partParameter.setAttribute("select", "id,keyed_name");
                partParameter = partParameter.apply();
                if (partParameter.getItemCount() > 0)
                {
                    productionCenter.Add(text);
                }
            }
            return productionCenter;
        }
    }
}