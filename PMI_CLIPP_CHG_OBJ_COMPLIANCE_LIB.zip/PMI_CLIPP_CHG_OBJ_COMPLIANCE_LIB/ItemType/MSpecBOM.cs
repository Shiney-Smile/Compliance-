﻿using Aras.IOM;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CommonDataModel;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType
{
    public class MSpecBOM
    {
        private Innovator innovator = null;
        public string id = string.Empty;
        public string keyedName = string.Empty;

        public MSpecBOM(Innovator innovator)
        {
            this.innovator = innovator;
        }

        public List<MspecDataModel> GetmSpecBOM(string mSpecID)
        {
            MspecDataModel mSpecDataModel = new MspecDataModel();
            List<Item> BOMItems = new List<Item>();
            List<Item> mSpecItems = new List<Item>();
            List<MspecDataModel> mSpecDataModelList = new List<MspecDataModel>();
            //Mspec MCO Affected Item
            if (!string.IsNullOrEmpty(mSpecID))
            {
                Item groupTree = innovator.newItem(ItemTypeName.mSpec, "GetItemRepeatConfig");
                groupTree.setID(mSpecID);
                groupTree.setAttribute("serverEvents", "0");
                Item memberLink = groupTree.createRelationship(ItemTypeName.mSpecBOM, "get");
                memberLink.setAttribute("repeatProp", "related_id");
                memberLink.setAttribute("repeatTimes", "8");
                groupTree.setAttribute("select", "id,item_number,related_id(id),classification");
                groupTree = groupTree.apply();
                if (groupTree.isError())
                {
                    throw new Exception("mSpec :: GetmSpecBOM Method :: Not able to retrive BOM.Mspec ID: " + mSpecID);
                }
                mSpecItems.Add(groupTree);
            }
            if (mSpecItems.Count > 0)
            {
                foreach (Item item in mSpecItems)
                {
                    Item getBomItem = item.getItemsByXPath("//Item/Relationships/Item[@type='pmi_LocalPartBOM']");
                    for (int getBomItemIndex = 0; getBomItemIndex < getBomItem.getItemCount(); getBomItemIndex++)
                    {
                        string? InputItemId = string.Empty;
                        string? ChildItemId = string.Empty;
                        string? ParentItemID = string.Empty;
                        string? ParentItemType = string.Empty;
                        string? InputItemNumber = string.Empty;
                        string? ParentItemNumber = string.Empty;
                        string? ParentItemClassification = string.Empty;
                        string? ChildItemNumber = string.Empty;
                        string? ChildItemType = string.Empty;
                        string? ChildItemClassification = string.Empty;

                        if (getBomItemIndex == 0)
                        {
                            InputItemId = item.getProperty("id", string.Empty);
                            ParentItemID = InputItemId;
                            ParentItemType = item.getType();
                            InputItemNumber = item.getProperty("item_number", string.Empty);
                            ParentItemNumber = item.getProperty("item_number", string.Empty);
                            ParentItemClassification = item.getProperty("classification", string.Empty);
                        }
                        else
                        {
                            if (mSpecDataModelList.Count > 0)
                            {
                                int bomCnt = getBomItem.getItemCount();
                                int cnt = getBomItemIndex - 1;
                                if (cnt <= bomCnt)
                                {
                                    InputItemId = mSpecDataModelList[cnt].childItemID;
                                    ParentItemID = mSpecDataModelList[cnt].childItemID;
                                    ParentItemClassification = mSpecDataModelList[cnt].childItemClassification;
                                    ParentItemType = mSpecDataModelList[cnt].childItemType;
                                    InputItemNumber = mSpecDataModelList[cnt].childItemCode;
                                    ParentItemNumber = mSpecDataModelList[cnt].childItemCode;
                                }
                            }
                        }

                        ChildItemId = getBomItem.getItemByIndex(getBomItemIndex).getProperty("related_id");
                        ChildItemNumber = getBomItem.getItemByIndex(getBomItemIndex).getProperty("pmi_item_code", string.Empty);
                        Item ChildRelatedItem = innovator.newItem(getBomItem.getItemByIndex(getBomItemIndex).getPropertyItem("related_id").getType(), "get");
                        ChildRelatedItem.setProperty("select", "type, classfication");
                        ChildRelatedItem.setProperty("id", ChildItemId);
                        ChildRelatedItem = ChildRelatedItem.apply();
                        ChildItemType = ChildRelatedItem.getType();
                        ChildItemClassification = ChildRelatedItem.getProperty("classification");

                        MspecDataModel mSpecDataModeItem = new MspecDataModel();

                        mSpecDataModeItem.inputItemID = InputItemId;
                        mSpecDataModeItem.parentItemID = ParentItemID;
                        mSpecDataModeItem.parentItemType = ParentItemType;
                        mSpecDataModeItem.parentItemClassification = ParentItemClassification;
                        mSpecDataModeItem.childItemID = ChildItemId;
                        mSpecDataModeItem.inputItemCode = InputItemNumber;
                        mSpecDataModeItem.parentItemCode = ParentItemNumber;
                        mSpecDataModeItem.childItemCode = ChildItemNumber;
                        mSpecDataModeItem.childItemType = ChildItemType;
                        mSpecDataModeItem.childItemClassification = ChildItemClassification;

                        Console.WriteLine("Input Id:" + InputItemId + " Parent ID:" + ParentItemID + " Child ID:" + ChildItemId);

                        mSpecDataModelList.Add(mSpecDataModeItem);
                    }
                }
            }
            return mSpecDataModelList;
        }
    }
}