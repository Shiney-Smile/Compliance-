﻿using Aras.IOM;
using Aras.IOME;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType.ChangeObject
{
    public class checkComplianceMCO
    {
        private Innovator innovator = null;
        private string id = string.Empty;
        private string keyed_name = string.Empty;

        public checkComplianceMCO(Innovator innovator)
        {
            this.innovator = innovator;
        }

        public checkComplianceMCO(Innovator innovator, string id, string keyed_name)
        {
            this.innovator = innovator;
            this.id = id;
            this.keyed_name = keyed_name;
        }

        public (string status, string complianceStatusMsg) checkComplianceOfBoMModel(string propertyCheck, string mSpecId, string mSpecPVId)
        {
            Console.WriteLine("Starting MCO compliance check for MSpec ID: " + mSpecId);
            MSpecDataModel md = new MSpecDataModel(innovator);
            Item getCompDataModel = md.GetMspecBoM(mSpecId, 0);
            string container = getCompDataModel.getProperty("pmi_container");
            string itemCode = getCompDataModel.getProperty("pmi_item_code");

            Console.WriteLine("BoM model retrieved. Container: " + container + ", Item Code: " + itemCode);
            string fetchDataModel = @"SELECT TOP(1) id FROM innovator.pmi_CompObjMspecBomDataModel with (nolock) WHERE PMI_ITEM_CODE LIKE '" + mSpecId + "' ORDER BY CREATED_ON DESC;";

            Item intermediateBomModel = innovator.applySQL(fetchDataModel);
            Console.WriteLine("Fetching intermediate BoM model:" + fetchDataModel);
            if (intermediateBomModel.isError())
            {
                throw new ItemErrorException("Intermediate Container Item Not Found!");
            }

            Item MCOVariable = innovator.newItem("Variable", "get");
            MCOVariable.setAttribute("select", "name,value");
            MCOVariable.setProperty("name", "pmi_IsMcoCompOtherLmtEnabled");
            MCOVariable = MCOVariable.apply();

            if (MCOVariable.isError())
            {
                Console.WriteLine("MCOVariable Error:" + MCOVariable.getErrorDetail());
            }

            string McoOtherLmtEnabled = MCOVariable.getProperty("value", "");


            //old approach
            
            Item sqlResult = innovator.newItem("SQL", "SQL PROCESS");
            sqlResult.setProperty("name", "pmi_MCOComplianceCheck");
            sqlResult.setProperty("PROCESS", "CALL");
            sqlResult.setProperty("ARG1", mSpecId);
         
            sqlResult.setProperty("ARG2", string.IsNullOrEmpty(mSpecPVId) ? "NULL" : mSpecPVId);
            sqlResult.setProperty("ARG3", intermediateBomModel.getID());
            sqlResult.setProperty("ARG4", McoOtherLmtEnabled);
            sqlResult = sqlResult.apply();
            Console.WriteLine("Execute stored procedure pmi_MCOComplianceCheck.." + ", ARG1:" + mSpecId + ", ARG2:" + mSpecPVId + ", ARG3:" + intermediateBomModel.getID() + "ARG4:" + McoOtherLmtEnabled);
            if (sqlResult.isError() || sqlResult.getItemCount() <= 0)
            {
                Console.WriteLine("error pmi_MCOComplianceCheck:" + sqlResult.getErrorDetail());
                throw new ItemErrorException("pmi_MCOComplianceCheck SQL error");
            }
            string complianceMsg = sqlResult.getProperty("pmi_status_message");
            string status = sqlResult.getProperty("pmi_compliance_status");




            //Item spResult = innovator.newItem("SQL", "SQL PROCESS");
            //spResult.setProperty("name", "pmi_MCOComplianceCheckRollUp");
            //spResult.setProperty("PROCESS", "CALL");
            //spResult.setProperty("ARG1", intermediateBomModel.getID());
            //spResult = spResult.apply();

            //if (spResult.isError())
            //{
            //    throw new ItemErrorException("Unable to fecth Tree Grid Stucture under BoM Model!");
            //}

            //int count = spResult.getItemCount();
            //List<string> status = new List<string>();

            //for (int i = 0; i < count; i++)
            //{
            //    Item itemByIndex = spResult.getItemByIndex(i);
            //    status.Add(itemByIndex.getProperty(propertyCheck, ""));
            //}

            //Item mcoComplianceChkMethod = callSQLMethod(innovator, mSpecId, mSpecPVId, intermediateBomModel.getID(), McoOtherLmtEnabled).GetAwaiter().GetResult();
            //if (mcoComplianceChkMethod.isError() || mcoComplianceChkMethod.getItemCount() <= 0)
            //{
            //    Console.WriteLine("MCO Compliance Error Check: 101=>" + mcoComplianceChkMethod.isError());
            //    Console.WriteLine("Unable to check the mco Compliance!"+ mcoComplianceChkMethod.getErrorString());
            //    throw new ItemErrorException("Unable to check the mco Compliance!"+mcoComplianceChkMethod.getErrorString());
            //}
            //Console.WriteLine("Able to check the mco Compliance!" + mcoComplianceChkMethod);
            //string complianceMsg = mcoComplianceChkMethod.getProperty("pmi_status_message");
            //string status = mcoComplianceChkMethod.getProperty("pmi_compliance_status");

            return (status, complianceMsg);
        }

        public async Task<Item> callSQLMethod(Innovator innovator, string mSpecId, string mSpecPVId, string intermediateBomModel, string McoOtherLmtEnabled)
        {
            var mcoComplianceCheckMethod = await getDataFromSP(innovator, mSpecId, mSpecPVId, intermediateBomModel, McoOtherLmtEnabled);            
            return mcoComplianceCheckMethod;
        }
        private static async Task<Item> getDataFromSP(Innovator innovator, string mSpecId, string mSpecPVId, string intermediateBomModel, string McoOtherLmtEnabled)
        {
            //New Approach by calling method
            Item mcoComplianceCheckMethod = innovator.newItem(ItemTypeName.method, "pmi_MCOComplianceCheckData");
            mcoComplianceCheckMethod.setProperty("mSpecId", mSpecId);
            if (string.IsNullOrEmpty(mSpecPVId))
            {
                mcoComplianceCheckMethod.setProperty("mSpecPVId", null);
            }
            else
            {
                mcoComplianceCheckMethod.setProperty("mSpecPVId", mSpecPVId);
            }
            mcoComplianceCheckMethod.setProperty("CompObjDataModelId", intermediateBomModel);
            mcoComplianceCheckMethod.setProperty("McoOtherLmtEnabled", McoOtherLmtEnabled);
            mcoComplianceCheckMethod = mcoComplianceCheckMethod.apply();

            if (mcoComplianceCheckMethod.isError() || mcoComplianceCheckMethod.isEmpty() || mcoComplianceCheckMethod.getItemCount() <= 0)
            {
                Console.WriteLine("Unable to fecth MCO Compliance check2!" + mcoComplianceCheckMethod.getErrorString());
                throw new ItemErrorException("Unable to fecth MCO Compliance check!"+ mcoComplianceCheckMethod.getErrorString());
            }
            Console.WriteLine("Execute stored procedure pmi_MCOComplianceCheck through pmi_MCOComplianceCheckData method..." + ", ARG1:" + mSpecId + ", ARG2:" + mSpecPVId + ", ARG3:" + intermediateBomModel + "ARG4:" + McoOtherLmtEnabled);

            return mcoComplianceCheckMethod;
        }

        public (string status, string complianceStatusMsg) checkmSpecComplianceOfBoMModel(string propertyCheck, string mSpecId, string mSpecPVId, string mSpecPartId, string pcId)
        {
            Console.WriteLine("Starting mSpec compliance check for MSpec ID: " + mSpecId);
            MSpecDataModel md = new MSpecDataModel(innovator);
            Item getCompDataModel = md.GetMspecBoM(mSpecId, 0);
            string container = getCompDataModel.getProperty("pmi_container");
            string itemCode = getCompDataModel.getProperty("pmi_item_code");

            Console.WriteLine("BoM model retrieved. Container: " + container + ", Item Code: " + itemCode);
            string fetchDataModel = @"SELECT TOP(1) id FROM innovator.pmi_CompObjMspecBomDataModel with (nolock) WHERE PMI_ITEM_CODE LIKE '" + mSpecId + "' ORDER BY CREATED_ON DESC;";
            Console.WriteLine("Fetching Data Model:" + fetchDataModel);
            Item intermediateBomModel = innovator.applySQL(fetchDataModel);
            if (intermediateBomModel.isError())
            {
                throw new ItemErrorException("Intermediate Container Item Not Found!" + intermediateBomModel.getErrorDetail());
            }

            Console.WriteLine("Execute stored procedure pmi_LOCmSPecComplianceCheck.." + ", ARG1:" + mSpecId + ", ARG2:" + mSpecPVId + ", ARG3:" + intermediateBomModel.getID() + "ARG4:" + pcId + "ARG5:" + mSpecPartId);
            Item sqlResult = innovator.newItem("SQL", "SQL PROCESS");
            sqlResult.setProperty("name", "pmi_LOCmSPecComplianceCheck");
            sqlResult.setProperty("PROCESS", "CALL");
            sqlResult.setProperty("ARG1", mSpecId);
            if (!string.IsNullOrEmpty(mSpecPVId))
            {
                sqlResult.setProperty("ARG2", mSpecPVId);
            }
            else
            {
                sqlResult.setProperty("ARG2", null);
            }

            sqlResult.setProperty("ARG3", intermediateBomModel.getID());
            sqlResult.setProperty("ARG4", pcId);
            if (!string.IsNullOrEmpty(mSpecPartId))
            {
                sqlResult.setProperty("ARG5", mSpecPartId);
            }
            else
            {
                sqlResult.setProperty("ARG5", null);
            }
            sqlResult = sqlResult.apply();


            if (sqlResult.isError() || sqlResult.getItemCount() != 1)
            {
                throw new ItemErrorException("Unable to fecth Tree Grid Stucture under BoM Model!" + sqlResult.getErrorDetail());
            }
            string complianceMsg = sqlResult.getProperty("pmi_status_message");
            string status = sqlResult.getProperty("pmi_compliance_status");
            Console.WriteLine("Compliance Message:" + complianceMsg + ", Status:" + status);
            return (status, complianceMsg);
        }
    }
}