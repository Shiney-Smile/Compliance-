﻿using Aras.IOM;
using Aras.IOME;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType.ChangeObject
{
    public class checkCompliancePECO
    {
        private Innovator innovator = null;
        private string id = string.Empty;
        private string keyed_name = string.Empty;
        public checkCompliancePECO(Innovator innovator)
        {
            this.innovator = innovator;
        }
        public checkCompliancePECO(Innovator innovator, string id, string keyed_name)
        {
            this.innovator = innovator;
            this.id = id;
            this.keyed_name = keyed_name;
        }

        public List<string> checkComplianceOfBoMModel(string propertyCheck, string partId, string pvId)
        {
            Item partItem = innovator.getItemById(ItemTypeName.Part, partId);
            string partName = partItem.getProperty("item_number");

            if (partItem.isError())
            {
                throw new ItemErrorException("Part Item Not Found!");
            }

            string partREV = partItem.getProperty("major_rev", "");

            string fetchDataModel = @"SELECT TOP(1) id FROM innovator.pmi_CompObjPartBoMDataModel with (nolock) WHERE PMI_ITEM_CODE LIKE '" + partId + "' ORDER BY CREATED_ON DESC;";
            
            Item intermediateBomModel = innovator.applySQL(fetchDataModel);
            if (intermediateBomModel.isError())
            {
                throw new ItemErrorException("Intermediate Container Item Not Found!");
            }

            Item sqlResult = innovator.newItem("SQL", "SQL PROCESS");
            sqlResult.setProperty("name", "pmi_ComplianceCheck");
            sqlResult.setProperty("PROCESS", "CALL");
            sqlResult.setProperty("ARG1", partId);
            sqlResult.setProperty("ARG2", intermediateBomModel.getID());
            sqlResult.setProperty("ARG3", pvId);
            sqlResult = sqlResult.apply();

            if (sqlResult.isError())
            {
                throw new ItemErrorException("Unable to fecth Tree Grid Stucture under BoM Model!");
            }
            int resultCount = sqlResult.getItemCount();

            string propertyName = string.Empty;
            if (resultCount > 0)
            {
                propertyName = sqlResult.getProperty(propertyCheck, "");
            }

            if (propertyName.Contains("NOT COMPLIANT"))
            {
                Console.WriteLine("DataModel is Non-Compliant");
                Console.WriteLine("Product Variant is Non-Compliant");
            }
            else
            {
                Console.WriteLine("DataModel is Compliant");
                Console.WriteLine("Product Variant is Compliant");
            }
            Item spResult = innovator.newItem("SQL", "SQL PROCESS");
            spResult.setProperty("name", "pmi_ComplianceCheckRollUp");
            spResult.setProperty("PROCESS", "CALL");
            spResult.setProperty("ARG1", intermediateBomModel.getID());
            spResult = spResult.apply();
            if (spResult.isError())
            {
                throw new ItemErrorException("Unable to fecth Tree Grid Stucture under BoM Model!");
            }
            int count = spResult.getItemCount();
            List<string> status = new List<string>();
            for (int i = 0; i < count; i++)
            {
                Item itemByIndex = spResult.getItemByIndex(i);
                status.Add(itemByIndex.getProperty(propertyCheck, ""));
            }
            for (int j = 0; j < count; j++)
            {
                Console.WriteLine(status[j]);
            }
            if (status.Contains("NOT COMPLIANT"))
            {

                Console.WriteLine("Part is Non Compliant");
            }
            else
            {
                Console.WriteLine("Part is Compliant");
            }
            return status;
        }
    }
}