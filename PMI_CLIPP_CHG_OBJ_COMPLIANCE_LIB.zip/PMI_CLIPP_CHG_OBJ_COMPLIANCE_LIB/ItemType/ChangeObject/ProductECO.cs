﻿using Aras.IOM;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CustomException;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util;
using System.Security.Cryptography.X509Certificates;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType.ChangeObject
{
    public class ProductECO
    {
        private Innovator innovator = null;
        public ProductECO(Innovator innovator)
        {
            this.innovator = innovator;
        }
        public List<Item> GetAffectedItems(string pecoID)
        {
            List<Item> AffectedItems = new List<Item>();

            Item pecoaffectedItemRel = innovator.newItem(ItemTypeName.ProductECOAffectedItem, "get");
            pecoaffectedItemRel.setProperty("source_id", pecoID);
            pecoaffectedItemRel.setAttribute("select", "new_item_id(id, pmi_product_category, pmi_product_type, keyed_name),pmi_target_lc");
            pecoaffectedItemRel = pecoaffectedItemRel.apply();

            if (pecoaffectedItemRel.isError() || pecoaffectedItemRel.isEmpty()) throw new PECORelationshipException();

            int affrelCount = pecoaffectedItemRel.getItemCount();
            for (int j = 0; j < affrelCount; j++)
            {
                Item pecoaffectItm = pecoaffectedItemRel.getItemByIndex(j);            
                Item newItem = pecoaffectItm.getPropertyItem("new_item_id");
                string itemType = newItem.getType();
                string targetLc = pecoaffectItm.getProperty("pmi_target_lc");

                if (ItemTypeName.ProductVariant.Equals(itemType) && !ItemTypeName.stateName.Equals(targetLc))
                {
                    AffectedItems.Add(newItem);
                }
                else
                {
                    continue;
                }
            }
            return AffectedItems;
        }
        public List<Item> GetPVAffectedItems(string pecoID)
        {
            List<Item> AffectedItems = new List<Item>();
            List<Item> PecoList = GetAffectedItems(pecoID);

            foreach (Item item in PecoList)
            {
                if (item.getType() == ItemTypeName.ProductVariant)
                {
                    AffectedItems.Add(item);
                }
            }
            return AffectedItems;
        }

        public List<Item> GetGPAffectedItems(string pecoID)
        {
            List<Item> AffectedItems = new List<Item>();
            List<Item> PecoList = GetAffectedItems(pecoID);

            foreach (Item item in PecoList)
            {
                if (item.getType() == ItemTypeName.GlobalProduct)
                {
                    AffectedItems.Add(item);
                }
            }
            return AffectedItems;
        }

        public List<Item> GetSPAffectedItems(string pecoID)
        {
            List<Item> AffectedItems = new List<Item>();
            List<Item> PecoList = GetAffectedItems(pecoID);

            foreach (Item item in PecoList)
            {
                if (item.getType() == ItemTypeName.SellableProduct)
                {
                    AffectedItems.Add(item);
                }
            }
            return AffectedItems;
        }
    }
}