﻿using Aras.IOM;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CustomException;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType.ChangeObject
{
    public class ExpresECO
    {
        private Innovator innovator = null;

        public ExpresECO(Innovator innovator)
        {
            this.innovator = innovator;
        }
        public List<Item> GetAffectedItems(string ecoID)
        {
            List<Item> AffectedItems = new List<Item>();

            Item ecoaffectedItemRel = innovator.newItem(ItemTypeName.ExpressECOAffectedItem, "get");
            ecoaffectedItemRel.setProperty("source_id", ecoID);
            ecoaffectedItemRel.setAttribute("select", "related_id(new_item_id)");
            ecoaffectedItemRel = ecoaffectedItemRel.apply();

            if (ecoaffectedItemRel.isError() || ecoaffectedItemRel.isEmpty())   throw new ECORelationshipException();
           
            int ecoaffectedItemRelCount = ecoaffectedItemRel.getItemCount();          
            for (int index = 0; index < ecoaffectedItemRelCount; index++)
            {
                Item partItem = innovator.newItem();
                Item affectedItemByIndex = ecoaffectedItemRel.getItemByIndex(index);
                partItem.setProperty("id", affectedItemByIndex.getPropertyItem("related_id").getProperty("new_item_id"));
                partItem.setProperty("name", affectedItemByIndex.getPropertyItem("related_id").getPropertyAttribute("new_item_id", "keyed_name"));

                AffectedItems.Add(partItem);
            }
            return AffectedItems;
        }
    }
}