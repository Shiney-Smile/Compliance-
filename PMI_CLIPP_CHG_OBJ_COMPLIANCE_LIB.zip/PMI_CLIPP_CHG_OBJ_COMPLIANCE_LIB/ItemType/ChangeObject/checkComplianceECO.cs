﻿using Amazon.Runtime.Internal;
using Aras.IOM;
using Aras.IOME;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.CompliancePolicy;
using Microsoft.SharePoint.Client.UserProfiles;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CommonDataModel;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util;
using PMI_CLIPP_TEST_APPLICATION;
using System.ComponentModel;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType.ChangeObject
{
    public class checkComplianceECO
    {
        private Innovator innovator = null;
        private string id = string.Empty;
        private string keyed_name = string.Empty;

        public checkComplianceECO(Innovator innovator)
        {
            this.innovator = innovator;
        }

        public checkComplianceECO(Innovator innovator, string id, string keyed_name)
        {
            this.innovator = innovator;
            this.id = id;
            this.keyed_name = keyed_name;
        }

        public (string status, string complianceStatusMsg, bool businessLmtFlag, bool complianceFlag) checkComplianceOfBoMModel(string propertyCheck, string partId, string pvId, string changeType)
        {
            string status = string.Empty;
            string complianceStatusMsg = string.Empty;
            List<string> complianceStatusResult = new List<string>();
            List<bool> businesslmtflaglist = new List<bool>();
            List<bool> complianceinputflaglist = new List<bool>();
            string complianceStatus = string.Empty;
            Item partItem = innovator.getItemById(ItemTypeName.Part, partId);
            string partName = partItem.getProperty("item_number");
            bool businessLmtFlag = false;
            bool complianceFlag = false;

            if (partItem.isError())
            {
                throw new ItemErrorException("Part Item Not Found!");
            }

            //Intermediate Data Model Creation 
            PartBoM pb = new PartBoM(innovator);
            Item getCompDataModel = pb.GetPartBoM(partName, partId, 0);
            string container = getCompDataModel.getProperty("pmi_container");
            string itemCode = getCompDataModel.getProperty("pmi_item_code");

            string fetchDataModel = @"SELECT TOP(1) id FROM innovator.pmi_CompObjPartBoMDataModel with (nolock) WHERE PMI_ITEM_CODE LIKE '" + partId + "' ORDER BY CREATED_ON DESC;";

            Item intermediateBomModel = innovator.applySQL(fetchDataModel);
            if (intermediateBomModel.isError())
            {
                throw new ItemErrorException("Intermediate Container Item Not Found!");
            }

            Item ECOVariable = innovator.newItem("Variable", "get");
            ECOVariable.setAttribute("select", "name,value");
            ECOVariable.setProperty("name", "pmi_IsEcoCompOtherLmtEnabled");
            ECOVariable = ECOVariable.apply();

            string EcoOtherLmtEnabled = ECOVariable.getProperty("value", "");

            Item PECOVariable = innovator.newItem("Variable", "get");
            PECOVariable.setAttribute("select", "name, value");
            PECOVariable.setProperty("name", "pmi_IsPecoCompOtherLmtEnabled");
            PECOVariable = PECOVariable.apply();

            string PecoOtherLmtEnabled = PECOVariable.getProperty("value", "");
            string pvIDvalue = string.IsNullOrEmpty(pvId) ? "NULL" : pvId;

            Item sqlResult = innovator.newItem("SQL", "SQL PROCESS");
            sqlResult.setProperty("name", "pmi_ComplianceCheck");
            sqlResult.setProperty("PROCESS", "CALL");
            sqlResult.setProperty("ARG1", partId);
            sqlResult.setProperty("ARG2", intermediateBomModel.getID());
            sqlResult.setProperty("ARG3", pvIDvalue);
            if (changeType == "pmi_ProductECO")
            {
                //spResult.setProperty("ARG3", pvId);
                sqlResult.setProperty("ARG4", PecoOtherLmtEnabled);
                sqlResult.setProperty("ARG5", "NULL");
            }
            else
           if (changeType == "Express ECO")
            {
                //spResult.setProperty("ARG3", "NULL");
                sqlResult.setProperty("ARG4", "NULL");
                sqlResult.setProperty("ARG5", EcoOtherLmtEnabled);
            }
            sqlResult = sqlResult.apply();

            if (sqlResult.isError())
            {
                Console.WriteLine(sqlResult.getErrorString());
                //throw new ItemErrorException("Unable to fecth Tree Grid Stucture under BoM Model!");
            }

            //Applying BOM Filtering Rules
            ApplyBOMRules applyBOMRules = new ApplyBOMRules(innovator);
            Item dataModel = applyBOMRules.ApplyRulesToBOM(itemCode, container, partItem);

            Item spResult = innovator.newItem("SQL", "SQL PROCESS");
            spResult.setProperty("name", "pmi_ComplianceDataModelRollup");
            spResult.setProperty("PROCESS", "CALL");
            spResult.setProperty("ARG1", partId);
            spResult.setProperty("ARG2", intermediateBomModel.getID());
            spResult.setProperty("ARG3", pvIDvalue);
            //if (!string.IsNullOrEmpty(pvId))
            if (changeType == "pmi_ProductECO")
            {
                //spResult.setProperty("ARG3", pvId);
                spResult.setProperty("ARG4", PecoOtherLmtEnabled);
                spResult.setProperty("ARG5", "NULL");
            }
            else
            if (changeType == "Express ECO")
            {
                //spResult.setProperty("ARG3", "NULL");
                spResult.setProperty("ARG4", "NULL");
                spResult.setProperty("ARG5", EcoOtherLmtEnabled);
            }
            spResult = spResult.apply();

            if (spResult.isError())
            {
                Console.WriteLine(spResult.getErrorString());
                //throw new ItemErrorException("Unable to fecth Tree Grid Stucture under BoM Model!");
            }

            //string complianceStatus = spResult.getProperty("pmi_compliance_status");
            string complianceMsg = spResult.getProperty("pmi_status_message");
            int spCount = spResult.getItemCount();

            for (int i = 0; i < spCount; i++)
            {
                Item itemByIndex = spResult.getItemByIndex(i);
                complianceStatusResult.Add(itemByIndex.getProperty("pmi_compliance_status", ""));
            }
            if (complianceStatusResult.Contains("OTHER LIMITATIONS"))
            {
                complianceStatus = "OTHER LIMITATIONS";
            }
            else if (complianceStatusResult.Contains("NOT COMPLIANT"))
            {
                complianceStatus = "NOT COMPLIANT";
            }
            else
            {
                complianceStatus = "COMPLIANT";
            }

            if (complianceStatus != "NOT COMPLIANT")
            {
                checkComplianceECO cc = new checkComplianceECO(innovator);
                var (businessLmtStatus, BusinessLmtStatusMsg) = cc.fetchBusinessCompStatus(innovator, propertyCheck, partId, pvId, changeType, partItem);
                //Consolidated Result of Compliance Input & Business Limitation
                if (complianceStatus == "COMPLIANT" && businessLmtStatus == "NOT COMPLIANT")
                {
                    status = businessLmtStatus;
                    complianceStatusMsg = BusinessLmtStatusMsg;
                    businessLmtFlag = true;
                }
                else if (complianceStatus == "OTHER LIMITATIONS" && businessLmtStatus == "NOT COMPLIANT")
                {
                    status = businessLmtStatus;
                    complianceStatusMsg = BusinessLmtStatusMsg;
                    businessLmtFlag = true;
                }
                else if (complianceStatus == "OTHER LIMITATIONS" && businessLmtStatus == "COMPLIANT")
                {
                    status = complianceStatus;
                    complianceStatusMsg = complianceMsg;
                    complianceFlag = true;
                }
                else if (complianceStatus == "COMPLIANT" && businessLmtStatus == "COMPLIANT")
                {
                    status = complianceStatus;
                    complianceStatusMsg = complianceMsg;
                    complianceFlag = true;
                }
            }
            else
            {
                status = complianceStatus;
                complianceStatusMsg = complianceMsg;
                complianceFlag = true;
            }
            return (status, complianceStatusMsg, businessLmtFlag, complianceFlag);
        }
        public (string businessLmtStatus, string BusinessLmtStatusMsg) fetchBusinessCompStatus(Innovator innovator, string propertyCheck, string partId, string pvId, string changeType, Item fetchPartItem)
        {
            List<string> businessLimitationstatus = new List<string>();
            string businessLmtStatus = string.Empty;
            string BusinessLmtStatusMsg = string.Empty;
            string propBusinessLmtCheck = "pmi_compliance_status";

            Item partItem = fetchPartItem;//innovator.getItemById(ItemTypeName.Part, partId);
            string partName = partItem.getProperty("item_number");

            if (partItem.isError())
            {
                throw new ItemErrorException("Part Item Not Found!");
            }

            ProductVariant pv = new ProductVariant(innovator);
            bool checkBusinessLmtType = pv.CheckBusinessLmtApplicabilityOfPart(partItem, changeType); //pv.CheckBusinessLmtApplicabilityOfPart(partName);
            if (checkBusinessLmtType == true)
            {
                //Intermediate Data Model Creation 
                PartBoM pbom = new PartBoM(innovator);
                Item getCompDataModelItem = pbom.GetPartBoM(partName, partId, 0);
                string container = getCompDataModelItem.getProperty("pmi_container");
                string itemCode = getCompDataModelItem.getProperty("pmi_item_code");

                string fetchDataModelId = @"SELECT TOP(1) id FROM innovator.pmi_CompObjPartBoMDataModel with (nolock) WHERE PMI_ITEM_CODE LIKE '" + partId + "' ORDER BY CREATED_ON DESC;";

                Item intermediateBomModelItem = innovator.applySQL(fetchDataModelId);
                if (intermediateBomModelItem.isError())
                {
                    throw new ItemErrorException("Intermediate Container Item Not Found!");
                }

                string spName = (changeType == "pmi_ProductECO") ? "pmi_BusinessLimitationCheck" : "pmi_ECOBusinessLimitationCheck";
                Item businessLmtSQLResult = innovator.newItem("SQL", "SQL PROCESS");
                businessLmtSQLResult.setProperty("name", spName);
                businessLmtSQLResult.setProperty("PROCESS", "CALL");
                businessLmtSQLResult.setProperty("ARG1", partId);
                businessLmtSQLResult.setProperty("ARG2", intermediateBomModelItem.getID());
                if(changeType == ItemTypeName.ProductECO)
                {
                    businessLmtSQLResult.setProperty("ARG3", pvId);
                }
                businessLmtSQLResult = businessLmtSQLResult.apply();

                //BusinessLmtStatusMsg = businessLmtSQLResult.getProperty("pmi_status_message");

                if (businessLmtSQLResult.isError())
                {
                    Console.WriteLine(businessLmtSQLResult.getErrorString());
                    //throw new ItemErrorException("Unable to fecth Tree Grid Stucture under BoM Model!");
                }
                //Applying BOM Filtering Rules
                ApplyBOMRules applyBOMRulesforBusinessLmt = new ApplyBOMRules(innovator);
                Item dataModel = applyBOMRulesforBusinessLmt.ApplyRulesToBOM(itemCode, container, partItem);

                string pvIDExist = string.IsNullOrEmpty(pvId) ? null : pvId;
                string spRollUPName = (changeType == "pmi_ProductECO") ? "pmi_BusinessLmtCheckRollUp" : "pmi_ECOBusinessLmtCheckRollUp";
                Item spRollUpResult = innovator.newItem("SQL", "SQL PROCESS");
                spRollUpResult.setProperty("name", spRollUPName);
                spRollUpResult.setProperty("PROCESS", "CALL");
                spRollUpResult.setProperty("ARG1", partId);
                spRollUpResult.setProperty("ARG2", intermediateBomModelItem.getID());
                if (changeType == ItemTypeName.ProductECO)
                {
                    spRollUpResult.setProperty("ARG3", pvIDExist);
                }
               // spRollUpResult.setProperty("ARG3", pvIDExist);
                spRollUpResult = spRollUpResult.apply();

                if (spRollUpResult.isError())
                {
                    Console.WriteLine(spRollUpResult.getErrorString());
                    //throw new ItemErrorException("Unable to fecth Tree Grid Stucture under BoM Model!");
                }
                BusinessLmtStatusMsg = spRollUpResult.getProperty("pmi_status_message");

                int spCount = spRollUpResult.getItemCount();

                for (int i = 0; i < spCount; i++)
                {
                    Item itemByIndex = spRollUpResult.getItemByIndex(i);
                    businessLimitationstatus.Add(itemByIndex.getProperty(propBusinessLmtCheck, ""));
                }
                if (businessLimitationstatus.Contains("NOT COMPLIANT"))
                {
                    businessLmtStatus = "NOT COMPLIANT";
                }
                else
                {
                    businessLmtStatus = "COMPLIANT";
                }
            }
            else
            {
                businessLmtStatus = "COMPLIANT";
            }
            return (businessLmtStatus, BusinessLmtStatusMsg);
        }
    }
}