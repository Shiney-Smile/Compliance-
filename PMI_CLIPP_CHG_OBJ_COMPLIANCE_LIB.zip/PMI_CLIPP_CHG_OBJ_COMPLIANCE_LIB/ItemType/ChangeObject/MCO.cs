﻿using Amazon.Runtime;
using Aras.IOM;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CommonDataModel;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util;
using System;
using System.Xml;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType.ChangeObject
{
    public class MCO
    {
        private Innovator innovator = null;

        public MCO(Innovator innovator)
        {
            this.innovator = innovator;
        }

        public Boolean CheckApplicabilityOfPartforMCO(string EBOMItem)
        {
            Item getEbomItem = innovator.getItemById(ItemTypeName.Part, EBOMItem);
            string type = getEbomItem.getProperty("classification", "");
            string subFamilyPart = getEbomItem.getProperty("pmi_sub_families", "");

            Item part = innovator.newItem(ItemTypeName.ChangeObjectProdCatMapping, "get");
            part.setProperty("pmi_part_item_type", type);
            part.setProperty("pmi_part_sub_family", subFamilyPart);
            part.setPropertyCondition("pmi_change_type", "like");
            part.setProperty("pmi_change_type", "%MCO%");
            part = part.apply();
            if (part.getItemCount() > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public List<Item> GetAffectedItems(string mSpecMCOID)
        {
            List<Item> AffectedItems = new List<Item>();

            Item affectedItem = innovator.newItem(ItemTypeName.MCOAffectedItem, "get");
            affectedItem.setProperty("source_id", mSpecMCOID);  //Mspec ID
            affectedItem.setAttribute("select", "pmi_new_item_id,pmi_target_lc,related_id(item_number,classification)");
            affectedItem.setAttribute("serverEvents", "0");
            affectedItem = affectedItem.apply();
            if (affectedItem.isError() || affectedItem.isEmpty())
            {
                throw new Exception("Mspec MCO :: GetAffectedItems Method :: Not able to retrive Mspec MCO. " + mSpecMCOID);
            }
            int affRelCount = affectedItem.getItemCount();
            for (int j = 0; j < affRelCount; j++)
            {
                Item affectedItemByIndex = affectedItem.getItemByIndex(j);
                string itemType = affectedItemByIndex.getPropertyItem("related_id").getProperty("classification");
                string itemNumber = affectedItemByIndex.getPropertyItem("related_id").getProperty("item_number");
                string newLifecycle = affectedItemByIndex.getProperty("pmi_target_lc", "");

                if (itemType == ItemTypeName.productVariantMspec
                    && (newLifecycle != ItemTypeName.stateName))
                {
                    List<string> mspecIDList = new List<string>();
                    string mSpecPVId = affectedItemByIndex.getProperty("pmi_new_item_id");
                    Item alternatives = innovator.newItem(ItemTypeName.mSpecBOM, "get");
                    alternatives.setProperty("source_id", mSpecPVId);  //product variant mspec ID
                    alternatives.setAttribute("select", "id, related_id(state, classification)");
                    alternatives = alternatives.apply();
                    if (alternatives.isEmpty() || alternatives.isError() || alternatives.getItemCount() <= 0)
                    {
                        continue;
                    }

                    bool isMspecApplicable = false;
                    int alternativesCount = alternatives.getItemCount();
                    for (int index = 0; index < alternativesCount; index++)
                    {
                        Item AffectedLocalPartItem = alternatives.getItemByIndex(index).getPropertyItem("related_id");
                        string mSpecAltState = AffectedLocalPartItem.getProperty("state", "");//mSpec Alt of PV mspec
                        string mSpecAltID = AffectedLocalPartItem.getProperty("id", "");

                        //First level lifecycle check- for mSpec Alternative
                        if ((itemType == ItemTypeName.productVariantMspec) && mSpecAltState != ItemTypeName.stateName
                            && mSpecAltState != ItemTypeName.cancelledState)
                        {
                            Item mSpecAltBOM = innovator.newItem(ItemTypeName.mSpecBOM, "get");
                            mSpecAltBOM.setProperty("source_id", mSpecAltID);  //BoM which will have Combustible and Consumable
                            mSpecAltBOM.setAttribute("select", "id, related_id(state, classification)");
                            mSpecAltBOM = mSpecAltBOM.apply();

                            if (mSpecAltBOM.isEmpty() || mSpecAltBOM.isError() || mSpecAltBOM.getItemCount() <= 0)
                            {
                                continue;
                            }
                            int mSpecAltBOMCount = mSpecAltBOM.getItemCount();

                            for (int a = 0; a < mSpecAltBOMCount; a++)
                            {
                                //To Find Combustible and Consumable
                                Item oneBOMItem = mSpecAltBOM.getItemByIndex(a).getPropertyItem("related_id");
                                string mspecClassification = oneBOMItem.getProperty("classification", "");
                                string mSpecId = oneBOMItem.getProperty("id", "");
                                string mSpecNumber = oneBOMItem.getPropertyAttribute("id", "keyed_name");
                                //Second Level check
                                if ((mspecClassification == ItemTypeName.combustibleMspec ||
                                    mspecClassification == ItemTypeName.consumableMspec))
                                {
                                    Item comConAlt = innovator.newItem(ItemTypeName.mSpecBOM, "get");
                                    comConAlt.setProperty("source_id", mSpecId);  //product variant mspec ID
                                    comConAlt.setAttribute("select", "id, related_id(state, classification, pmi_ebom_item)");
                                    comConAlt = comConAlt.apply();
                                    if (comConAlt.isEmpty() || comConAlt.isError() || comConAlt.getItemCount() <= 0)
                                    {
                                        continue;
                                        //throw new Exception("mspec :: " + mSpecNumber +" :: Not able to retrieve mspec alternative.");
                                    }

                                    int comConAltCnt = comConAlt.getItemCount();
                                    for (int index1 = 0; index1 < comConAltCnt; index1++)
                                    {
                                        Item AffectedAlternativeItm = comConAlt.getItemByIndex(index1).getPropertyItem("related_id");
                                        string mSpecAlternativeState = AffectedAlternativeItm.getProperty("state", "");//mSpec Alt of PV mspec
                                        string mSpecAlternativeID = AffectedAlternativeItm.getProperty("id", "");
                                        string mSpecAlternativeNumber = AffectedAlternativeItm.getPropertyAttribute("id", "keyed_name");
                                        string EBOMItem = AffectedAlternativeItm.getProperty("pmi_ebom_item", "");

                                        //check applicability only if mSpec is not applicable (only for first time)
                                        if (isMspecApplicable == false)
                                        {
                                            isMspecApplicable = CheckApplicabilityOfPartforMCO(EBOMItem);
                                        }
                                        if (isMspecApplicable == true)
                                        {
                                            //First level lifecycle check- for mSpec Alternative
                                            if (mSpecAlternativeState != ItemTypeName.stateName
                                            && mSpecAlternativeState != ItemTypeName.cancelledState)
                                            {
                                                Item mSpecItem = innovator.newItem();
                                                mSpecItem.setProperty("mspecpvid", mSpecPVId);
                                                mSpecItem.setProperty("mSpecPVNumber", itemNumber);
                                                mSpecItem.setProperty("mSpecNumber", itemNumber);
                                                mSpecItem.setProperty("mspecid", mSpecPVId);
                                                mSpecItem.setProperty("mspecAltId", mSpecAlternativeID);
                                                mSpecItem.setProperty("mSpecAltNumber", mSpecAlternativeNumber);
                                                mSpecItem.setProperty("mSpecType", itemType);
                                                AffectedItems.Add(mSpecItem);
                                                isMspecApplicable = true;
                                                //break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    //moved flag one level up so that all affectedItems are considered
                }
                else if (itemType == ItemTypeName.combustibleMspec || itemType == ItemTypeName.consumableMspec)
                {
                    string mSpecId = affectedItemByIndex.getProperty("pmi_new_item_id");
                    string mSpecNumber = affectedItemByIndex.getPropertyAttribute("id", "keyed_name");
                    Item mSpecAlternative = innovator.newItem(ItemTypeName.mSpecBOM, "get");
                    mSpecAlternative.setProperty("source_id", mSpecId);  //product variant mspec ID
                    mSpecAlternative.setAttribute("select", "id, related_id(state, classification, pmi_ebom_item)");
                    mSpecAlternative = mSpecAlternative.apply();
                    if (mSpecAlternative.isEmpty() || mSpecAlternative.isError() || mSpecAlternative.getItemCount() <= 0)
                    {
                        continue;
                        //throw new Exception("mspec :: " + mSpecNumber + " :: Not able to retrieve mspec alternative.");
                    }
                    bool isMspecApplicable = false;
                    int mSpecAlternativeCnt = mSpecAlternative.getItemCount();
                    for (int index1 = 0; index1 < mSpecAlternativeCnt; index1++)
                    {
                        Item AffectedAlternativeItm = mSpecAlternative.getItemByIndex(index1).getPropertyItem("related_id");
                        string mSpecAlternativeState = AffectedAlternativeItm.getProperty("state", "");//mSpec Alt of PV mspec
                        string mSpecAlternativeID = AffectedAlternativeItm.getProperty("id", "");
                        string mSpecAlternativeNumber = AffectedAlternativeItm.getPropertyAttribute("id", "keyed_name");
                        string EBOMItem = AffectedAlternativeItm.getProperty("pmi_ebom_item", "");

                        if (isMspecApplicable == false)
                        {
                            isMspecApplicable = CheckApplicabilityOfPartforMCO(EBOMItem);
                        }
                        if (isMspecApplicable == true)
                        {
                            //First level lifecycle check- for mSpec Alternative
                            if (mSpecAlternativeState != ItemTypeName.stateName
                                && mSpecAlternativeState != ItemTypeName.cancelledState)
                            {
                                Item mSpecItem = innovator.newItem();
                                mSpecItem.setProperty("mspecAltId", mSpecAlternativeID);
                                mSpecItem.setProperty("mSpecAltNumber", mSpecAlternativeNumber);
                                mSpecItem.setProperty("mspecid", mSpecId);
                                mSpecItem.setProperty("mSpecNumber", itemNumber);
                                mSpecItem.setProperty("mSpecType", itemType);
                                AffectedItems.Add(mSpecItem);
                                isMspecApplicable = true;
                                //break;
                            }
                        }
                    }
                }
                else if (itemType == ItemTypeName.filtermspec || itemType == ItemTypeName.filtersemimspec)
                {
                    string mSpecId = affectedItemByIndex.getProperty("pmi_new_item_id");
                    string mSpecNumber = affectedItemByIndex.getPropertyAttribute("id", "keyed_name");

                    Item mSpecAlternative = innovator.newItem(ItemTypeName.mSpecBOM, "get");
                    mSpecAlternative.setProperty("source_id", mSpecId);
                    mSpecAlternative.setAttribute("select", "id, related_id(state, classification, pmi_ebom_item, item_number)");
                    mSpecAlternative = mSpecAlternative.apply();

                    if (mSpecAlternative.isError() || mSpecAlternative.getItemCount() <= 0)
                    {
                        continue;
                        //throw new Exception("mspec :: " + mSpecNumber + " :: Not able to retrieve mspec alternative.");
                    }
                    bool isMspecApplicable = false;
                    int alternativesCount = mSpecAlternative.getItemCount();
                    for (int index1 = 0; index1 < alternativesCount; index1++)
                    {
                        Item AffectedAlternativeItm = mSpecAlternative.getItemByIndex(index1).getPropertyItem("related_id");
                        string mSpecAlternativeState = AffectedAlternativeItm.getProperty("state", "");
                        string mSpecAlternativeID = AffectedAlternativeItm.getProperty("id", "");
                        string mSpecAlternativeNumber = AffectedAlternativeItm.getPropertyAttribute("id", "keyed_name");
                        string mSpecAltEBOMItemId = AffectedAlternativeItm.getProperty("pmi_ebom_item", "");
                        string mspecAltItemCode = AffectedAlternativeItm.getProperty("item_number", "");
                        string sqlQuery = string.Empty;
                        string partItemType = string.Empty;

                        if (itemType == ItemTypeName.filtermspec)
                        {
                            partItemType = "Filter - 34";
                        }
                        else
                        {
                            partItemType = "Filter Semi - 33";
                        }

                        Item sqlResult = innovator.newItem("SQL", "SQL PROCESS");
                        sqlResult.setProperty("name", "pmi_FilterandFilterSemiPartCodeSQL");
                        sqlResult.setProperty("PROCESS", "CALL");
                        sqlResult.setProperty("ARG1", partItemType);
                        sqlResult.setProperty("ARG2", mspecAltItemCode);
                        sqlResult = sqlResult.apply();

                        if (sqlResult.isError())
                        {
                            throw new Exception("SQL Execution Error: " + sqlResult.getErrorDetail());
                        }

                        string resultXml = sqlResult.getResult();

                        if (string.IsNullOrWhiteSpace(resultXml))
                        {
                            //throw new Exception("No PartCodes returned from SQL query. Filter mspec is not linked to any " +
                            //    "Combustible/Consumable mspecs");
                            break;
                        }

                        int partCodeCnt = sqlResult.getItemCount();

                        for (int index = 0; index < partCodeCnt; index++)
                        {
                            Item partCodeItem = sqlResult.getItemByIndex(index);
                            string partCodefromSQL = partCodeItem.getProperty("partcode");

                            Item getPartItem = innovator.newItem(ItemTypeName.Part, "get");
                            getPartItem.setProperty("item_number", partCodefromSQL);
                            getPartItem.setAttribute("select", "id, item_number");
                            getPartItem = getPartItem.apply();

                            string partCode = getPartItem.getProperty("id");

                            if (isMspecApplicable == false)
                            {
                                isMspecApplicable = CheckApplicabilityOfPartforMCO(partCode);
                            }

                            // You can act based on the result here
                            if (isMspecApplicable == true)
                            {
                                //First level lifecycle check- for mSpec Alternative
                                if (mSpecAlternativeState != ItemTypeName.stateName
                                    && mSpecAlternativeState != ItemTypeName.cancelledState)
                                {
                                    Item mSpecItem = innovator.newItem();
                                    mSpecItem.setProperty("mspecAltId", mSpecAlternativeID);
                                    mSpecItem.setProperty("mSpecAltNumber", mSpecAlternativeNumber);
                                    mSpecItem.setProperty("mspecid", mSpecId);
                                    mSpecItem.setProperty("mSpecNumber", itemNumber);
                                    mSpecItem.setProperty("mSpecType", itemType);
                                    if (!AffectedItems.Contains(mSpecItem))
                                    {
                                        AffectedItems.Add(mSpecItem);
                                    }
                                    isMspecApplicable = true;
                                    //break;
                                }
                            }
                        }
                    }
                }
            }
            return AffectedItems;
        }
    }
}