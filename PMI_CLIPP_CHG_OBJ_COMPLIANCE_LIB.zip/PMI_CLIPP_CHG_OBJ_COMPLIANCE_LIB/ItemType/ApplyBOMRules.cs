﻿using Aras.IOM;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util;
using System.Reflection.Metadata.Ecma335;

namespace PMI_CLIPP_TEST_APPLICATION
{
    public class ApplyBOMRules
    {
        private Innovator _innovator;

        public ApplyBOMRules(Innovator innovator)
        {
            _innovator = innovator;
        }
        public Item ApplyRulesToBOM(string partID, string container, Item getPart)
        {
            if (getPart == null)
            {
                throw new Exception("Part item details could not be fetched.");
            }

            Item hideComplianceBOMRules = GetHideComplianceBOMRules(getPart, container);
            if (hideComplianceBOMRules == null)
            {
                throw new Exception("No compliance BOM rules found for the part.");
            }
            return hideComplianceBOMRules;
        }

        private Item GetHideComplianceBOMRules(Item getPart, string container)
        {
            string query = $"select id from innovator.pmi_ComplianceBOMHideRulesNew " +
                           $"where pmi_parent_item_type = '{getPart.getProperty("classification", "")}' " +
                           $"and pmi_enable = '1'";

            Item resultID = _innovator.applySQL(query);

            if (resultID.isError() || resultID.isEmpty() || resultID.getItemCount() <= 0)
            {
                return null;
            }

            string ruleID = resultID.getItemByIndex(0).getID();
            Item hideCompRules = _innovator.newItem(ItemTypeName.ComplianceBOMHideRules, "get");
            hideCompRules.setID(ruleID);

            Item itemTypesToHide = _innovator.newItem(ItemTypeName.ListofItemTypesToHide, "get");
            hideCompRules.addRelationship(itemTypesToHide);
            itemTypesToHide.setAttribute("orderBy", "sort_order ASC");

            hideCompRules.setAttribute("select", "id,pmi_parent_item_type,related_id(id,pmi_parent_part_item_type,pmi_child_part_item_type,pmi_bre)");
            hideCompRules = hideCompRules.apply();

            Item dataModel = _innovator.newItem(ItemTypeName.ComplianceObjectDataModel, "get");
            dataModel.setProperty("pmi_item_code", getPart.getID());
            dataModel.setProperty("pmi_type", "Part");
            dataModel.setProperty("pmi_container", container);
            dataModel = dataModel.apply();

            if (dataModel.isError())
            {
                throw new Exception($"Error getting Tree Grid BOM Data Model: {dataModel.getErrorString()}");
            }

            if (!hideCompRules.isError() && hideCompRules.getItemCount() > 0)
            {
                Item relationships = hideCompRules.getRelationships();
                int relCount = relationships.getItemCount();

                for (int i = 0; i < relCount; i++)
                {
                    Item relationship = relationships.getItemByIndex(i);
                    string parentXPath = relationship.getPropertyAttribute("pmi_parent_part_item_type", "keyed_name");
                    string childXPath = relationship.getPropertyAttribute("pmi_child_part_item_type", "keyed_name");
                    string bre = relationship.getPropertyAttribute("pmi_bre", "keyed_name");
                    string parentID = relationship.getProperty("source_id", "");
                    string dataModelId = dataModel.getItemByIndex(0).getProperty("id", "");
                    string applicable = relationship.getProperty("pmi_enable");

                    if (applicable == "1")
                    {

                        Item breResult = _innovator.applyMethod(bre,
                        $"<parentXPath>{parentXPath}</parentXPath>" +
                        $"<childXPath>{childXPath}</childXPath>" +
                        $"<dataModel>{dataModelId}</dataModel>" +
                        $"<idOfReplicatedBOMRules>{parentID}</idOfReplicatedBOMRules>");

                        if (breResult.isError())
                        {
                            throw new Exception($"Error applying BOM filtering rule: {breResult.getErrorString()}");
                        }
                    }
                }
            }
            return dataModel;
        }
    }
}