﻿using Aras.IOM;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType.ChangeObject
{
    public class MSpecDataModel
    {
        private Innovator innovator = null;
        private string id = string.Empty;
        private string keyed_name = string.Empty;
        public MSpecDataModel(Innovator innovator)
        {
            this.innovator = innovator;
        }
        public MSpecDataModel(Innovator innovator, string id, string keyed_name)
        {
            this.innovator = innovator;
            this.id = id;
            this.keyed_name = keyed_name;
        }

        public Item GetMspecBoM(string mSpecId, int count)
        {
            if (string.IsNullOrEmpty(mSpecId))
            {
                throw new ArgumentNullException("Mspec ID is Empty");
            }
            Item methodResult = innovator.newItem(ItemTypeName.method, "pmi_CreateCompObjmSpecBom");
            methodResult.setProperty("mSpecId", mSpecId);
            methodResult = methodResult.apply();
            //Item methodResult = innovator.applyMethod("pmi_CreateCompObjmSpecBom", "<mSpecId>" + mSpecId + "</mSpecId>");

            //if (methodResult.isError())
            //{
            if (methodResult.getErrorString().Contains("System.Net.WebException"))
            {
                count = count + 1;
                if (count > 10)
                {
                    return null;
                }
                GetMspecBoM(mSpecId, count);
            }
            //throw new Exception("Error in getting Items in Method" + methodResult.getErrorString());
            //}
            return methodResult;
        }
    }
}