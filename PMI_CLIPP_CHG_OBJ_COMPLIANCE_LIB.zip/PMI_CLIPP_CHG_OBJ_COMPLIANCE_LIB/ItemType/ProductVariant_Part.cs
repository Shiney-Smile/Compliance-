﻿using Aras.IOM;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CustomException;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util;
using System.Diagnostics.Contracts;
using System.IO;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType
{
    public class ProductVariant_Part
    {
        private Innovator innovator = null;
        public string id { get; set; }
        public string keyedName { get; set; }
        public string pvName { get; set; }
        public string marketName { get; set; }
        public string changeType = string.Empty;
        public ProductVariant_Part(Innovator innovator)
        {
            this.innovator = innovator;
        }
        public ProductVariant_Part(Innovator innovator, string itemId, string keyedName, string pvName, string marketName)
        {
            this.innovator = innovator;
            this.id = itemId;
            this.keyedName = keyedName;
            this.pvName = pvName;
            this.marketName = marketName;
        }

        public bool CheckApplicabilityOfPV(string productCategoryLable, string productTypeLable)
        {
            Item pvpartItem = innovator.newItem(ItemTypeName.PVPartSelection, "get");
            pvpartItem.setProperty("pmi_pvproductcategory", productCategoryLable);
            pvpartItem.setProperty("pmi_pvproducttype", productTypeLable);
            pvpartItem = pvpartItem.apply();
            if (pvpartItem.getItemCount() > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool ProductVariantApplicabilityCheck(string pvID)
        {
            bool pvApplicability = false;
            string partValue = "";
            String[] parts = [];
            try
            {
                string aml = string.Format(@"<AML><Item type='pmi_ProductVariant' action='get' id='{0}' select='keyed_name,pmi_product_category,pmi_product_type'>                                     
                                        <Relationships>
                                            <Item type='pmi_PVItemSelection' action='get'>
                                            </Item>
                                        </Relationships>
                                       </Item></AML>", pvID);
                Item pv = innovator.applyAML(aml);
                
                if (pv.isError())
                {
                    throw new Exception("Part: GetAllPartFromPV(): Product Varient ID not found: " + pvID);
                }
                string pvName = pv.getProperty("keyed_name", "");
                string productCategory = pv.getProperty("pmi_product_category");
                string productType = pv.getProperty("pmi_product_type");
                string productCategoryLable = ItemHelper.GetListLableFromValue(innovator, List.ProductCateoryListId, List.ValueRelationItemType, productCategory);
                string productTypeLable = ItemHelper.GetListLableFromValue(innovator, List.ProductLableId, List.FilterValueRelationshipItemType, productType);

                Item pvpartItem = innovator.newItem(ItemTypeName.PVPartSelection, "get");
                pvpartItem.setProperty("pmi_pvproductcategory", productCategoryLable);
                pvpartItem.setProperty("pmi_pvproducttype", productTypeLable);
                pvpartItem.setProperty("select", "pmi_parametertoselectpartfrom, pmi_ghp");
                pvpartItem = pvpartItem.apply();

                //Returning false because we were facing issue for IsError when the PVPartItem Count was zero.
                if (pvpartItem.isError())
                {
                    return false;
                }
                int pvpartItemCnt = pvpartItem.getItemCount();
                for (int k = 0; k < pvpartItemCnt; k++)
                {
                    Item psItemfromPVPartSelection = pvpartItem.getItemByIndex(k).getPropertyItem("pmi_parametertoselectpartfrom");
                    string parameterStructureID = psItemfromPVPartSelection.getProperty("id");
                    Item psItem = innovator.getItemById(ItemTypeName.ParameterStructure, parameterStructureID);
                    string psNumberfromPVPartSelection = psItem.getProperty("pmi_parameter_number");
                    string ghpNumberfromPVPartSelection = pvpartItem.getItemByIndex(k).getProperty("pmi_ghp");

                    Item relationshipItem = pv.getRelationships("pmi_PVItemSelection");
                    if (relationshipItem.isError())
                    {
                        throw new Exception("Part: GetAllPartFromPV(): parameter structure is not found for "+ pvName);
                    }
                    int count = relationshipItem.getItemCount();

                    bool isPsNumberFound = false;
                    for (int index = 0; index < count; index++)
                    {
                        Item affectedRowItem = relationshipItem.getItemByIndex(index);
                        string psNumber = affectedRowItem.getProperty("pmi_parameter_number");
                        string psId = affectedRowItem.getProperty("id");

                        if (string.IsNullOrEmpty(psNumber) || string.IsNullOrEmpty(psId))
                        {
                            throw new Exception("Part: GetAllPartFromPV(): PS Number or PS Id not found for "+ pvName);
                        }
                        if (psNumberfromPVPartSelection == psNumber)
                        {
                            isPsNumberFound = true;
                            Item ghpItem = innovator.newItem(ItemTypeName.StructureGHPContainers, "get");
                            ghpItem.setProperty("source_id", psId);
                            ghpItem.setAttribute("select", "id,keyed_name,related_id");
                            ghpItem.setAttribute("serverEvents", "0");
                            ghpItem = ghpItem.apply();
                            if (ghpItem.isError())
                            {
                                continue;
                            }
                            int ghpCount = ghpItem.getItemCount();
                            for (int i = 0; i < ghpCount; i++)
                            {
                                Item ghp = ghpItem.getItemByIndex(i);
                                string related_id = ghp.getProperty("related_id");
                                Item relatedItem = ghp.getRelatedItem();
                                if (relatedItem.isError())
                                {
                                    throw new Exception("Part: GetAllPartFromPV(): PMI_PVGHPCONTAINERS is not found for "+ pvName);
                                }
                                string ghpNumber = relatedItem.getPropertyAttribute("pmi_parameter_number", "keyed_name", "");
                                if (ghpNumber == ghpNumberfromPVPartSelection)
                                {
                                    partValue = relatedItem.getProperty("pmi_parameter_value");
                                    //partValue = relatedItem.getPropertyAttribute("pmi_item_container", "keyed_name", "");  //New Line added

                                    if (!string.IsNullOrEmpty(partValue) && partValue != "N/A")    //new line 
                                    {
                                        parts = partValue.Split(";");
                                    }
                                    break;
                                }
                            }
                        }
                        else
                        {
                            continue;
                        }
                    }
                }
                foreach (string Part in parts)
                {

                    if (String.IsNullOrEmpty(Part))
                    {
                        continue;
                    }
                    else
                    {
                        ProductVariant prodVar = new ProductVariant(innovator);
                        string partName = Part.Trim();
                        pvApplicability = prodVar.CheckApplicabilityOfPart(partName, changeType);
                        if (pvApplicability == true)
                        {
                            break;
                        }
                    }
                }
                return pvApplicability;
            }
            catch (Exception e)
            {
                throw new Exception("PV applicability Exception " + e);
            }
        }
        public List<ProductVariant_Part> GetAllPartFromPV(string pvNumber, string pvID)
        {

            List<ProductVariant_Part> collection = new List<ProductVariant_Part>();
            String[] partKeyedName = [];
            List<Tuple<string, string, string, string, string, string>> datalist = new List<Tuple<string, string, string, string, string, string>>();
            List<Item> psCollection = new List<Item>();
            List<string> partCollection = new List<string>();

            try
            {
                string aml = string.Format(@"<AML><Item type='pmi_ProductVariant' action='get' id='{0}' select='keyed_name,pmi_product_category,pmi_product_type'>                                     
                                        <Relationships>
                                            <Item type='pmi_PVItemSelection' action='get'>
                                            </Item>
                                        </Relationships>
                                       </Item></AML>", pvID);
                Item pv = innovator.applyAML(aml);
                if (pv.isError())
                {
                    throw new Exception("Part: GetAllPartFromPV(): Product Variant ID not found: " + pvID);
                }
                string productCategory = pv.getProperty("pmi_product_category");
                string productType = pv.getProperty("pmi_product_type");
                string productCategoryLable = ItemHelper.GetListLableFromValue(innovator, List.ProductCateoryListId, List.ValueRelationItemType, productCategory);
                string productTypeLable = ItemHelper.GetListLableFromValue(innovator, List.ProductLableId, List.FilterValueRelationshipItemType, productType);

                if (!CheckApplicabilityOfPV(productCategoryLable, productTypeLable))
                {
                    throw new Exception("Part: GetAllPartFromPV(): Applicability criteria for PV "+ pvNumber + " not found!");
                }
                //new code
                Item pvpartItems = innovator.newItem(ItemTypeName.PVPartSelection, "get");
                pvpartItems.setProperty("pmi_pvproductcategory", productCategoryLable);
                pvpartItems.setProperty("pmi_pvproducttype", productTypeLable);
                pvpartItems.setProperty("select", "pmi_parametertoselectpartfrom, pmi_ghp");
                pvpartItems = pvpartItems.apply();
                if (pvpartItems.isError())
                {
                    throw new Exception("Error in getting PVPartSelection item for PV "+ pvNumber);
                }
                int pvpartItemsCnt = pvpartItems.getItemCount();
                for (int k = 0; k < pvpartItemsCnt; k++)
                {
                    Item psItemfromPVPartSelection = pvpartItems.getItemByIndex(k).getPropertyItem("pmi_parametertoselectpartfrom");
                    string parameterStructureID = psItemfromPVPartSelection.getProperty("id");
                    Item psItem = innovator.getItemById(ItemTypeName.ParameterStructure, parameterStructureID);
                    string psNumberfromPVPartSelection = psItem.getProperty("pmi_parameter_number");
                    string ghpNumberfromPVPartSelection = pvpartItems.getItemByIndex(k).getProperty("pmi_ghp");

                    bool isPsNumberFound = false;

                    Item relationshipItem = pv.getRelationships("pmi_PVItemSelection");
                    if (relationshipItem.isError())
                    {
                        throw new Exception("Part: GetAllPartFromPV(): parameter structure is not found for PV " + pvNumber);
                    }
                    int count = relationshipItem.getItemCount();

                    for (int index = 0; index < count; index++)
                    {
                        Item affectedRowItem = relationshipItem.getItemByIndex(index);
                        string psNumber = affectedRowItem.getProperty("pmi_parameter_number");
                        string psId = affectedRowItem.getProperty("id");
                        if (string.IsNullOrEmpty(psNumber) || string.IsNullOrEmpty(psId))
                        {
                            throw new Exception("Part: GetAllPartFromPV(): PS Number or PS Id not found for PV "+ pvNumber);
                        }

                        if (psNumberfromPVPartSelection == psNumber)
                        {
                            isPsNumberFound = true;
                            Item ghpItem = innovator.newItem(ItemTypeName.StructureGHPContainers, "get");
                            ghpItem.setProperty("source_id", psId);
                            ghpItem.setAttribute("select", "id,keyed_name,related_id");
                            ghpItem.setAttribute("serverEvents", "0");
                            ghpItem = ghpItem.apply();
                            if (ghpItem.isError())
                            {
                                continue;
                            }
                            int ghpItemCount = ghpItem.getItemCount();
                            for (int i = 0; i < ghpItemCount; i++)
                            {
                                Item ghp = ghpItem.getItemByIndex(i);
                                string related_id = ghp.getProperty("related_id");
                                Item relatedItem = ghp.getRelatedItem();
                                if (relatedItem.isError())
                                {
                                    throw new Exception("Part: GetAllPartFromPV(): PMI_PVGHPCONTAINERS is not found for PV "+ pvNumber);
                                }
                                string ghpNumber = relatedItem.getPropertyAttribute("pmi_parameter_number", "keyed_name", "");
                                string ghpId = relatedItem.getProperty("pmi_parameter_number");
                                string partValue = string.Empty;
                                if (ghpNumber == ghpNumberfromPVPartSelection)
                                {
                                    partValue = relatedItem.getProperty("pmi_parameter_value");
                                    //partValue = relatedItem.getPropertyAttribute("pmi_item_container", "keyed_name", "");//newly added line
                                    if (!string.IsNullOrEmpty(partValue))
                                    {
                                        partKeyedName = partValue.Split(";");
                                    }
                                    string sql = string.Format("select keyed_name from innovator.PMI_GLOBALHARMONIZEDPARAMETERS (nolock) where id='{0}'", ghpId);
                                    Item relatedItm = innovator.applySQL(sql);
                                    if (relatedItm.isError() || relatedItm.getItemCount() <= 0)
                                    {
                                        throw new Exception("Part: GetAllPartFromPV(): GHP value not found:" + ghpId);
                                    }
                                    string ghp_Name = relatedItm.getProperty("keyed_name");

                                    foreach (var part in partKeyedName)
                                    {
                                        if (!string.IsNullOrEmpty(part))
                                        {
                                            datalist.Add(new Tuple<string, string, string, string, string, string>(productCategoryLable, productTypeLable, psNumber, ghp_Name, part.Trim(), pv.getProperty("keyed_name")));
                                        }
                                    }
                                }
                                //string partValue = relatedItem.getProperty("pmi_parameter_value");
                            }

                        }
                    }
                }

                Item pvpartItem = innovator.newItem(ItemTypeName.PVPartSelection, "get");
                pvpartItem.setProperty("pmi_pvproductcategory", productCategoryLable);
                pvpartItem.setProperty("pmi_pvproducttype", productTypeLable);
                pvpartItem = pvpartItem.apply();
                if (pvpartItem.isError())
                {
                    throw new Exception("Part: GetAllPartFromPV(): pmi_PVPartSelection not found for PV "+ pvNumber);
                }
                int pvpartItemcount = pvpartItem.getItemCount();
                for (int index = 0; index < pvpartItemcount; index++)
                {
                    string pvPSId = pvpartItem.getItemByIndex(index).getProperty("pmi_parametertoselectpartfrom");
                    Item parameterStructure = innovator.newItem(ItemTypeName.ParameterStructure, "get");
                    parameterStructure.setProperty("id", pvPSId);
                    parameterStructure.setAttribute("select", "keyed_name");
                    parameterStructure.setAttribute("serverEvents", "0");
                    parameterStructure = parameterStructure.apply();
                    if (parameterStructure.isError())
                    {
                        throw new Exception("Part: GetAllPartFromPV(): Parameter structure not found for PV "+ pvNumber);
                    }
                    string psKeyedName = parameterStructure.getProperty("keyed_name");
                    string pvghplist = pvpartItem.getItemByIndex(index).getProperty("pmi_ghp");

                    foreach (var tuple in datalist)
                    {
                        string prodCat = tuple.Item1;
                        string prodtype = tuple.Item2;
                        string ps = tuple.Item3;
                        string ghpnum = tuple.Item4;
                        string value = tuple.Item5;
                        string pvName = tuple.Item6;

                        List<ProductVariant> marketCollection = new List<ProductVariant>();
                        ProductVariant varient = new ProductVariant(innovator);

                        Item market = varient.GetMarketRelByPV(pvID);

                        if (market.isError() || market.getItemCount() <= 0)
                        {
                            continue;
                        }
                        for (int i = 0; i < market.getItemCount(); i++)
                        {
                            Item marketName = varient.GetMarketByRel(market.getItemByIndex(i).getProperty("related_id"));
                            if (marketName == null)
                            {
                                throw new ArgumentNullException("ProductVariant::FetchPV() : market data is null.");
                            }

                            //seperated GHP list by comma
                            if (!string.IsNullOrEmpty(pvghplist))
                            {
                                string[] ghplistData;
                                if (pvghplist.ToString().Contains(","))
                                {
                                    ghplistData = pvghplist.ToString().Split(',');
                                }
                                else
                                {
                                    ghplistData = new string[] { pvghplist.ToString() };
                                }
                                foreach (string pvghp in ghplistData)
                                {
                                    if (ps.Equals(psKeyedName) && ghpnum.Equals(pvghp))
                                    {
                                        //seperated value list by comma
                                        if (!string.IsNullOrEmpty(value))
                                        {
                                            string[] dividedData;
                                            if (value.ToString().Contains(","))
                                            {
                                                dividedData = value.ToString().Split(',');
                                            }
                                            else
                                            {
                                                dividedData = new string[] { value.ToString() };
                                            }
                                            foreach (string items in dividedData)
                                            {
                                                HashSet<string> addedParts = new HashSet<string>();
                                                Item part = ItemHelper.GetItemByKeyedName(innovator, ItemTypeName.Part, items.ToString());
                                                if (!part.isError())
                                                {
                                                    for (int partId = 0; partId < part.getItemCount(); partId++)
                                                    {
                                                        string partName = part.getItemByIndex(partId).getProperty("id", "");
                                                        if (!addedParts.Contains(partName))
                                                        {
                                                            //adding new part for a single time in addedParts HashSet for avoiding duplicates
                                                            addedParts.Add(partName);
                                                            collection.Add(new ProductVariant_Part(innovator, part.getItemByIndex(partId).getProperty("id", ""), part.getItemByIndex(partId).getProperty("keyed_name", ""), pvName, marketName.getProperty("keyed_name")));
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

            }
            catch (Exception e)
            {
                throw new Exception("Part: GetAllPartFromPV(): Error " + e.ToString());
            }
            return collection;
        }
    }
}