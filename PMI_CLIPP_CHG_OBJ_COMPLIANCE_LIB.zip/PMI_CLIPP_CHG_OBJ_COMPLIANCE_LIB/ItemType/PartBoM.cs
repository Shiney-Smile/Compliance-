﻿using Aras.IOM;
//using Aras.IOME;
//using Microsoft.SharePoint.News.DataModel;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType.ChangeObject
{
    public class PartBoM
    {
        private Innovator innovator = null;
        private string id = string.Empty;
        private string keyed_name = string.Empty;
        public PartBoM(Innovator innovator)
        {
            this.innovator = innovator;
        }
        public PartBoM(Innovator innovator, string id, string keyed_name)
        {
            this.innovator = innovator;
            this.id = id;
            this.keyed_name = keyed_name;
        }

        public Item GetPartBoM(string partName, string partId, int count)
        {
            if (string.IsNullOrEmpty(partName) || string.IsNullOrEmpty(partId))
            {
                throw new ArgumentNullException("Part Name OR Part ID is Empty");
            }

            Item sqlResult = innovator.newItem("SQL", "SQL PROCESS");
            sqlResult.setProperty("name", "pmi_getCompPartBomItems");
            sqlResult.setProperty("PROCESS", "CALL");
            sqlResult.setProperty("ARG1", partId);
            sqlResult.setProperty("ARG2", partName);
            sqlResult = sqlResult.apply();

            if (sqlResult.getErrorString().Contains("System.Net.WebException"))
            {
                count = count + 1;
                if (count > 10)
                {
                    return null;
                }
                GetPartBoM(partName, partId, count);
            }
            return sqlResult;
        }
    }
}