﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType
{
    public class List
    {
        public const string ItemType = "List";

        public const string ValueRelationItemType = "Value";

        public const string FilterValueRelationshipItemType = "Filter Value";

        public const string ProductCateoryListId = "931B7DAC0E3346C89AF24AA52CE61A25";

        public const string ProductLableId = "8606A8FC41FD4D51A982102488BF2E19";

    }
}
