﻿using Aras.IOM;
using PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.Util;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.ItemType
{
    public class Part
    {
        private Innovator innovator = null;

        public string id = string.Empty;
        public string keyedName = string.Empty;
        public string pvName = string.Empty;
        public string marketName = string.Empty;
        List<Part> partList = new List<Part>();
        public Part(Innovator innovator)
        {
            this.innovator = innovator;
        }
        public Part(Innovator innovator, string itemId, string keyedName, string pvName, string marketName)
        {
            this.innovator = innovator;
            this.id = itemId;
            this.keyedName = keyedName;
            this.pvName = pvName;
            this.marketName = marketName;
        }

        public Item GetPartById(string GetPartById)
        {
            Item partItm = innovator.newItem();
            partItm = innovator.newItem(ItemTypeName.Part, "get");
            partItm.setProperty("id", GetPartById);
            partItm.setAttribute("select", "id,item_number, classification");
            partItm = partItm.apply();

            if (partItm.isError() || partItm.isEmpty())
            {
                throw new Exception("Part :: GetPartById Method :: Not able to retrive Part. Part ID" + GetPartById);
            }
            return partItm;
        }

        public Item GetPartByKeyedName(string partName)
        {
            Item part = innovator.newItem(ItemTypeName.Part, "get");
            part.setPropertyCondition("keyed_name", "like");
            part.setProperty("keyed_name", partName);
            part.setAttribute("select", "id,keyed_name");
            part.setAttribute("serverEvents", "0");
            part = part.apply();
            return part;
        }
    }
}