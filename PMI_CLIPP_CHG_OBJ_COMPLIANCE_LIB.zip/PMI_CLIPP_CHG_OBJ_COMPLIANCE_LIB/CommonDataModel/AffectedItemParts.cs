﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CommonDataModel
{
    public class AffectedItemParts
    {
        public string partId { get; set; }
        public string partNumber { get; set; }
        public string subFamilyPart { get; set; }
        public string changeType { get; set; }
        public string changeId { get; set; }
        public string changeNumber { get; set; }
        public string complianceResult { get; set; }
        public string otherLimitationComments { get; set; }
        public ErrorInformation Error { get; set; }
    }
}
