﻿using System.Security.Policy;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CommonDataModel
{
    public class MspecDataModel
    {
        public string inputItemID { get; set; }
        public string parentItemID { get; set; }

        public string parentItemType { get; set; }
        public string parentItemClassification { get; set; }
        public string childItemID { get; set; }
        public string itemType { get; set; }
        public string inputItemCode { get; set; }
        public string parentItemCode { get; set; }
        public string childItemCode { get; set; }

        public string childItemType { get; set; }

        public string childItemClassification { get; set; }
    }
}