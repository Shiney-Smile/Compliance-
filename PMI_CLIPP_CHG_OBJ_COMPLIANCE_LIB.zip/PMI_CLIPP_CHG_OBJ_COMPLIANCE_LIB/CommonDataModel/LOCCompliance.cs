﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CommonDataModel
{
    public class LOCCompliance
    {
        public string item_type { get; set; }
        public string item_id { get; set; }
        public string mspecAltId1 { get; set; }
        public string production_center { get; set; }
        public string context_item_id { get; set; }
        public string context_item_type { get; set; }
        public string context_item_keyed_name { get; set; }
        public string pmi_item_code { get; set; }
        public string complianceResult { get; set; }
        public string statusMessage { get; set; }
        public ErrorInformation Error { get; set; }
    }
}
