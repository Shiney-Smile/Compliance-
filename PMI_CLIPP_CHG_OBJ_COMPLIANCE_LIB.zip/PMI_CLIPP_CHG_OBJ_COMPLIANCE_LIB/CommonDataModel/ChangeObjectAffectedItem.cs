﻿using Microsoft.Office.Client.TranslationServices;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CommonDataModel
{
    public class ChangeObjectAffectedItem
    {
        public string partId { get; set; }
        public string partNumber { get; set; }
        public string subFamilyPart { get; set; }
        public string partItemType { get; set; }
        public string changeType { get; set; }
        public string changeId { get; set; }
        public string changeNumber { get; set; }
        public string pvId { get; set; }
        public string pvNumber { get; set; }
        public string pvProductCategoryLabel { get; set; }
        public string pvProductTypeLabel { get; set; }
        public string complianceResult { get; set; }
        public string otherLimitationComments { get; set; }
        public string statusMessage { get; set; }
        public string mSpecNumber { get; set; }
        public string mSpecId { get; set; }
        public string mSpecPVId { get; set; }
        public string mSpecAltId { get; set; }
        public string mSpecAltNumber { get; set; }
        public string mSpecPVNumber { get; set; }
        public ErrorInformation Error { get; set; }
        public string mSpecType { get; set;}
        public string item_type { get; set; }
        public string item_id { get; set; }
        public string production_center { get; set; }
        public string context_item_id { get; set; }
        public string context_item_type { get; set; }
        public string context_item_keyed_name { get; set; }
        public bool LocalizationScreen { get; set; }
        public string pmi_item_code { get; set; }
        public string pmi_child_compliance_status { get; set; }
        public string pmi_business_compliance { get; set; }
        public string pmi_container { get; set; }
        public bool businessLimitationflag { get; set; }
        public bool complianceInputflag { get; set; }
        public string username { get; set; }
        public bool isPVApplicable { get; set; }
        public string CheckType { get; set; }
        public List<ChangeObjectAffectedItem> partComplainceCheckCollection { get; set; }
        public string mSpecAltOldId { get; set; }
        public int affectedItemCount { get; set; }
        public string activityID { get; set; }
    }
}