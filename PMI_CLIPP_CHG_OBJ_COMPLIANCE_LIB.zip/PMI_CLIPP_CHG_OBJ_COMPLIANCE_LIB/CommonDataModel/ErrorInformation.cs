﻿using Microsoft.SharePoint.Client.Discovery;

namespace PMI_CLIPP_CHG_OBJ_COMPLIANCE_LIB.CommonDataModel
{
    public class ErrorInformation
    {
        public bool IsError { get; set; }
        public string ErrorMessage { get; set; }
        public string ExceptionStackTrace { get; set; }
        public static ErrorInformation ConvertExceptionToErrorInformation(Exception ex)
        {
            ErrorInformation errorInformation = new ErrorInformation();
            errorInformation.IsError = true;
            errorInformation.ErrorMessage = ex.Message;
            errorInformation.ExceptionStackTrace = ex.StackTrace;
            return errorInformation;
        }

        public static ErrorInformation GeneratePositiveErrorInformation()
        {
            ErrorInformation errorInformation = new ErrorInformation();
            errorInformation.IsError = false;
            errorInformation.ErrorMessage = "";
            errorInformation.ExceptionStackTrace = "";
            return errorInformation;
        }

        public static ErrorInformation ErrorInfoForPartApplicability()
        {
            ErrorInformation errorInformation = new ErrorInformation();
            errorInformation.IsError = false;
            errorInformation.ErrorMessage = "Change Object Product Category Mapping not present for this affected item";
            errorInformation.ExceptionStackTrace = "";
            return errorInformation;
        }
        public static ErrorInformation GeneratePositiveErrorInfoForPVOtherLimitations(string pvNumber)
        {
            ErrorInformation errorInformation = new ErrorInformation();
            errorInformation.IsError = true;
            errorInformation.ErrorMessage = "Valid PV Part Selection item does not exist for PV: "+pvNumber;
            errorInformation.ExceptionStackTrace = "";
            return errorInformation;
        }
        public static ErrorInformation GeneratePositiveErrorInfoForNullAffectedItemsForPV(string pvNumber)
        {
            ErrorInformation errorInformation = new ErrorInformation();
            errorInformation.IsError = false;
            errorInformation.ErrorMessage = pvNumber+" : Affected item for PV does not exist";
            errorInformation.ExceptionStackTrace = "";
            return errorInformation;
        }

        public static ErrorInformation GeneratePositiveErrorInfoForNullAffectedItemsForMspec()
        {
            ErrorInformation errorInformation = new ErrorInformation();
            errorInformation.IsError = false;
            errorInformation.ErrorMessage = "Affected item for Mspec does not exist";
            errorInformation.ExceptionStackTrace = "";
            return errorInformation;
        }

        public static ErrorInformation ErrorECOReportGeneration()
        {
            ErrorInformation errorInformation = new ErrorInformation();
            errorInformation.IsError = false;
            errorInformation.ErrorMessage = "Method pmi_GenECOCompReport: Not able to generate report";
            errorInformation.ExceptionStackTrace = "";
            return errorInformation;
        }

        public static ErrorInformation ErrorPECOReportGeneration()
        {
            ErrorInformation errorInformation = new ErrorInformation();
            errorInformation.IsError = false;
            errorInformation.ErrorMessage = "Method pmi_GenPECOCompReport: Not able to generate report";
            errorInformation.ExceptionStackTrace = "";
            return errorInformation;
        }

        public static ErrorInformation ErrorMCOReportGeneration()
        {
            ErrorInformation errorInformation = new ErrorInformation();
            errorInformation.IsError = false;
            errorInformation.ErrorMessage = "Method pmi_GenMCOCompReport: Not able to generate report";
            errorInformation.ExceptionStackTrace = "";
            return errorInformation;
        }
    }
}